"""
合并4个资产测绘xlsx文档，按(域名 + IP + 端口)去重，
保留: 序号, HOST, 标题, IP, 域名, 端口, 协议, 服务指纹, 城市
扩展: 利用, 结果
"""

import os
import openpyxl
from openpyxl.styles import Font, Alignment, Border, Side, PatternFill

# ---------- 配置 ----------
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
INPUT_DIR = SCRIPT_DIR
OUTPUT_FILE = os.path.join(SCRIPT_DIR, "合并去重_资产测绘.xlsx")

# 要保留的源列名（第2行表头），按顺序
KEEP_COLUMNS = ["序号", "HOST", "标题", "IP", "域名", "端口", "协议", "服务指纹", "城市"]
# 额外扩展的列
EXTRA_COLUMNS = ["利用", "结果"]

# 去重标准：按这些列判断重复
DEDUP_KEYS = ["域名", "IP", "端口"]


def find_xlsx_files(directory):
    """找目录下所有非临时 xlsx 文件（排除输出文件自身）"""
    output_basename = os.path.basename(OUTPUT_FILE)
    return sorted([
        f for f in os.listdir(directory)
        if f.endswith(".xlsx")
        and not f.startswith("~$")
        and f != output_basename
    ])


# 用于识别表头行的特征列名（只需匹配其中部分即认定是表头）
HEADER_SIGNATURES = {"HOST", "IP", "域名", "端口", "协议"}


def detect_header_row(ws):
    """
    自动检测表头所在行：扫描前 5 行，找到包含最多特征列名的行。
    返回 (header_row_number, headers_list)
    """
    best_row = 1
    best_headers = []
    best_score = 0

    max_check = min(ws.max_row, 5)
    for row_idx in range(1, max_check + 1):
        row_values = [cell.value for cell in ws[row_idx]]
        # 统计该行命中了多少特征列名
        score = sum(
            1 for v in row_values
            if v is not None and str(v).strip() in HEADER_SIGNATURES
        )
        if score > best_score:
            best_score = score
            best_row = row_idx
            best_headers = row_values

    return best_row, best_headers


def read_sheet(filepath):
    """
    读取一个xlsx，自动识别表头行，返回 [dict] 列表
    """
    wb = openpyxl.load_workbook(filepath)
    ws = wb.active

    header_row, headers = detect_header_row(ws)
    data_start = header_row + 1

    print(f"    表头位于第{header_row}行, 特征匹配数={sum(1 for v in headers if v is not None and str(v).strip() in HEADER_SIGNATURES)}")

    rows = []
    for row in ws.iter_rows(min_row=data_start, max_row=ws.max_row, values_only=True):
        row_dict = {}
        for i, value in enumerate(row):
            if i < len(headers) and headers[i] is not None:
                row_dict[headers[i]] = value
        # 跳过完全空行
        if any(v is not None for v in row_dict.values()):
            rows.append(row_dict)

    wb.close()
    return rows, headers


def normalize_value(val):
    """用于去重比较的值标准化"""
    if val is None:
        return ""
    return str(val).strip()


def main():
    print("=" * 60)
    print("资产测绘 xlsx 合并去重脚本")
    print("=" * 60)

    # 1. 找到所有文件
    files = find_xlsx_files(INPUT_DIR)
    print(f"\n发现 {len(files)} 个文件:")
    for f in files:
        print(f"  - {f}")

    # 2. 读取并合并
    all_rows = []
    for f in files:
        filepath = os.path.join(INPUT_DIR, f)
        try:
            rows, _ = read_sheet(filepath)
            print(f"  读取 {f}: {len(rows)} 条记录")
            all_rows.extend(rows)
        except Exception as e:
            print(f"  [跳过] {f}: 读取失败 - {e}")

    print(f"\n合并后总计: {len(all_rows)} 条")

    # 3. 去重（按 域名 + IP + 端口）
    seen = set()
    deduped = []
    for row in all_rows:
        key = tuple(
            normalize_value(row.get(k)) for k in DEDUP_KEYS
        )
        if key not in seen:
            seen.add(key)
            deduped.append(row)

    removed = len(all_rows) - len(deduped)
    print(f"去重移除: {removed} 条")
    print(f"去重后保留: {len(deduped)} 条")

    # 4. 按 IP 排序，相同 IP 的资产相邻
    def sort_key(row):
        ip = normalize_value(row.get("IP", ""))
        # 将 IP 拆分为数字元组以保证正确排序（如 10.1.1.2 < 10.1.1.20）
        try:
            parts = [int(p) for p in ip.split(".")]
        except (ValueError, AttributeError):
            parts = [0, 0, 0, 0]
        port = normalize_value(row.get("端口", ""))
        try:
            port_num = int(port)
        except (ValueError, AttributeError):
            port_num = 0
        return (parts, port_num)

    deduped.sort(key=sort_key)
    print(f"已按 IP + 端口 排序")

    # 4.5 域名筛选：有域名的行只保留匹配主域名的，无域名的行不变
    print("\n" + "-" * 40)
    print("域名筛选：请输入要保留的主域名，每行一个")
    print("示例: guoquanwx.com  或  gqsh.cc")
    print("输入空行或'确定'结束")
    print("-" * 40)

    main_domains = []
    while True:
        d = input("  主域名 > ").strip()
        if d == "确定" or d == "":
            break
        main_domains.append(d)

    if main_domains:
        print(f"\n要保留的主域名: {', '.join(main_domains)}")

        filtered = []
        removed_domain_rows = 0
        for row in deduped:
            domain = normalize_value(row.get("域名", ""))
            if domain:
                # 有域名：检查是否匹配任一主域名（忽略大小写）
                domain_lower = domain.lower()
                matched = any(
                    domain_lower == md.lower() or domain_lower.endswith("." + md.lower())
                    for md in main_domains
                )
                if matched:
                    filtered.append(row)
                else:
                    removed_domain_rows += 1
            else:
                # 无域名（纯IP）：保留
                filtered.append(row)

        deduped = filtered
        print(f"域名不匹配移除: {removed_domain_rows} 条")
        print(f"筛选后保留: {len(deduped)} 条")
    else:
        print("未输入主域名，跳过筛选")

    # 5. 写入新 xlsx
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "合并去重"

    # ---- 样式 ----
    header_font = Font(name="微软雅黑", size=11, bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    header_alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    thin_border = Border(
        left=Side(style="thin"),
        right=Side(style="thin"),
        top=Side(style="thin"),
        bottom=Side(style="thin"),
    )
    data_alignment = Alignment(vertical="center")

    # 写表头行
    output_headers = KEEP_COLUMNS + EXTRA_COLUMNS
    for col_idx, h in enumerate(output_headers, 1):
        cell = ws.cell(row=1, column=col_idx, value=h)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_alignment
        cell.border = thin_border

    # 超链接样式
    link_font = Font(name="微软雅黑", size=10, color="0563C1", underline="single")

    # HOST 列的索引（1-based）
    HOST_COL_IDX = KEEP_COLUMNS.index("HOST") + 1  # 序号=1, HOST=2

    # 写数据行
    for row_idx, row_data in enumerate(deduped, 2):
        # 重新生成序号
        ws.cell(row=row_idx, column=1, value=row_idx - 1).alignment = data_alignment
        ws.cell(row=row_idx, column=1).border = thin_border

        for col_idx, col_name in enumerate(KEEP_COLUMNS[1:], 2):  # 从第2列开始（序号已写）
            val = row_data.get(col_name, "")
            cell = ws.cell(row=row_idx, column=col_idx, value=val)
            cell.alignment = data_alignment
            cell.border = thin_border

            # HOST 列设为可点击超链接（自动补全协议前缀）
            if col_idx == HOST_COL_IDX and val:
                val_str = str(val)
                if val_str.startswith(("http://", "https://")):
                    hyperlink_target = val_str
                else:
                    # 根据协议列判断用 http 还是 https
                    protocol = str(row_data.get("协议", "")).lower()
                    if "https" in protocol or "ssl" in protocol:
                        hyperlink_target = "https://" + val_str
                    else:
                        hyperlink_target = "http://" + val_str
                cell.hyperlink = hyperlink_target
                cell.font = link_font

        # 扩展列留空
        for extra_idx, extra_name in enumerate(EXTRA_COLUMNS, len(KEEP_COLUMNS) + 1):
            cell = ws.cell(row=row_idx, column=extra_idx, value="")
            cell.alignment = data_alignment
            cell.border = thin_border

    # 列宽自适应
    col_widths = {
        1: 8,    # 序号
        2: 42,   # HOST
        3: 28,   # 标题
        4: 18,   # IP
        5: 32,   # 域名
        6: 8,    # 端口
        7: 12,   # 协议
        8: 18,   # 服务指纹
        9: 12,   # 城市
        10: 14,  # 利用
        11: 20,  # 结果
    }
    for col, width in col_widths.items():
        ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = width

    # 冻结首行
    ws.freeze_panes = "A2"

    # 保存（如被 Excel 占用则自动加时间戳）
    try:
        wb.save(OUTPUT_FILE)
        final_path = OUTPUT_FILE
    except PermissionError:
        import datetime
        ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        name, ext = os.path.splitext(OUTPUT_FILE)
        final_path = f"{name}_{ts}{ext}"
        wb.save(final_path)
        print(f"\n[WARN] 原输出文件被占用，已另存为时间戳版本")

    print(f"\n[OK] 输出文件: {final_path}")
    print(f"  共 {len(deduped)} 条记录，{len(output_headers)} 列")
    print("=" * 60)


if __name__ == "__main__":
    main()
