# -*- coding: utf-8 -*-
"""
止戈为武 - PassionSec - ICP备案查询模块
查询流程学习自 ICP_Query-0.7.0，针对工信部备案系统 API

查询流程：
  1. 获取 auth token: POST /api/auth  (form-encoded, authKey = MD5("testtest" + timestamp))
  2. 滑块验证码识别: 获取图片 → numpy/PIL 匹配缺口 → 提交偏移量 → 获得 sign
  3. 按条件查询: POST /api/icpAbbreviateInfo/queryByCondition (带 sign + uuid 头)
  4. APP/小程序/快应用: 并发获取详情

查询类型 serviceType:
  1 → 网站
  6 → APP
  7 → 小程序
  8 → 快应用

支持: 普通备案查询 + 违法违规域名/APP查询
"""
import base64
import hashlib
import io
import json
import random
import ssl
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.request import Request, urlopen
from urllib.error import URLError

# 可选依赖：验证码识别
try:
    import numpy as np
    from PIL import Image
    HAS_CAPTCHA_DEPS = True
except ImportError:
    HAS_CAPTCHA_DEPS = False

# ════════════════════════════════════════
# SSL 证书校验绕过
# ════════════════════════════════════════
_SSL_CONTEXT = ssl.create_default_context()
_SSL_CONTEXT.check_hostname = False
_SSL_CONTEXT.verify_mode = ssl.CERT_NONE

# ════════════════════════════════════════
# API 端点
# ════════════════════════════════════════
AUTH_URL = "https://hlwicpfwc.miit.gov.cn/icpproject_query/api/auth"
QUERY_URL = "https://hlwicpfwc.miit.gov.cn/icpproject_query/api/icpAbbreviateInfo/queryByCondition"
BLACK_QUERY_URL = "https://hlwicpfwc.miit.gov.cn/icpproject_query/api/blackListDomain/queryByCondition"
BLACK_APP_MINI_URL = "https://hlwicpfwc.miit.gov.cn/icpproject_query/api/blackListDomain/queryByCondition_appAndMini"
DETAIL_URL = "https://hlwicpfwc.miit.gov.cn/icpproject_query/api/icpAbbreviateInfo/queryDetailByAppAndMiniId"
CAPTCHA_IMAGE_URL = "https://hlwicpfwc.miit.gov.cn/icpproject_query/api/image/getCheckImagePoint"
CAPTCHA_CHECK_URL = "https://hlwicpfwc.miit.gov.cn/icpproject_query/api/image/checkImage"

# ════════════════════════════════════════
# 查询类型映射
# ════════════════════════════════════════
QUERY_TYPE_MAP = {
    "web":  {"serviceType": 1, "name": "网站"},
    "app":  {"serviceType": 6, "name": "APP"},
    "mini": {"serviceType": 7, "name": "小程序"},
    "kuai": {"serviceType": 8, "name": "快应用"},
}

BLACK_TYPE_MAP = {
    "web":  {"serviceType": 1, "name": "违法违规网站"},
    "app":  {"serviceType": 6, "name": "违法违规APP"},
    "mini": {"serviceType": 7, "name": "违法违规小程序"},
    "kuai": {"serviceType": 8, "name": "违法违规快应用"},
}

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/101.0.4951.41 Safari/537.36 Edg/101.0.1210.32")


def _http_post(url, data=None, json_data=None, form_data=None, headers=None, timeout=30):
    """发送 HTTP POST 请求，返回响应体字符串"""
    if headers is None:
        headers = {}
    if "User-Agent" not in headers:
        headers["User-Agent"] = UA

    if json_data is not None:
        body = json.dumps(json_data, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    elif form_data is not None:
        from urllib.parse import urlencode
        body = urlencode(form_data).encode("utf-8")
        headers["Content-Type"] = "application/x-www-form-urlencoded"
    elif data is not None:
        if isinstance(data, str):
            body = data.encode("utf-8")
        else:
            body = data
    else:
        body = None

    req = Request(url, data=body, headers=headers, method="POST")
    try:
        resp = urlopen(req, context=_SSL_CONTEXT, timeout=timeout)
        return resp.read().decode("utf-8")
    except URLError as e:
        raise ConnectionError(f"HTTP请求失败: {e}")


class IcpQueryEngine:
    """ICP 备案查询引擎（自动处理 token + 验证码）"""

    def __init__(self):
        self._token = ""
        self._token_expire = 0
        self._detail_concurrency = 5
        # 验证码相关缓存
        self._captcha_sign = ""
        self._captcha_uuid = ""
        self._captcha_sign_expire = 0

    # ════════════════════════════════════
    # Token 管理
    # ════════════════════════════════════
    def _get_token(self):
        """获取 auth token（带缓存）"""
        if self._token and self._token_expire > int(time.time() * 1000):
            return self._token

        timestamp = int(time.time() * 1000)
        auth_secret = "testtest" + str(timestamp)
        auth_key = hashlib.md5(auth_secret.encode("utf-8")).hexdigest()

        headers = {
            "Origin": "https://beian.miit.gov.cn",
            "Referer": "https://beian.miit.gov.cn/",
            "Cookie": f"__jsluid_s={uuid.uuid4().hex}",
            "Accept": "application/json, text/plain, */*",
        }
        resp_text = _http_post(AUTH_URL, form_data={
            "authKey": auth_key, "timeStamp": timestamp
        }, headers=headers)

        if "当前访问疑似黑客攻击" in resp_text:
            raise RuntimeError("当前访问已被创宇盾拦截，请更换IP后重试")

        result = json.loads(resp_text)
        if not result.get("success"):
            raise RuntimeError(f"获取token失败: {result.get('msg', '未知错误')}")

        self._token = result["params"]["bussiness"]
        self._token_expire = int(time.time() * 1000) + result["params"]["expire"]
        return self._token

    # ════════════════════════════════════
    # 验证码处理
    # ════════════════════════════════════
    @staticmethod
    def _gen_client_uid():
        """生成 clientUid（仿原版 UUID v4 格式）"""
        chars = "0123456789abcdef"
        uid = [random.choice(chars) for _ in range(36)]
        uid[14] = "4"
        uid[19] = chars[(3 & int(uid[19], 16)) | 8]
        uid[8] = uid[13] = uid[18] = uid[23] = "-"
        return "point-" + "".join(uid)

    @staticmethod
    def _match_slider_offset(small_image_b64, big_image_b64):
        """在大图上找与滑块同尺寸的纯色正方形缺口区域，返回其 x 偏移量"""
        if not HAS_CAPTCHA_DEPS:
            return False, "缺少 numpy/Pillow 依赖，无法识别验证码。请执行: pip install numpy Pillow"

        big_img = np.array(Image.open(io.BytesIO(base64.b64decode(big_image_b64))).convert("RGB"))
        small_img = np.array(Image.open(io.BytesIO(base64.b64decode(small_image_b64))))
        sh, sw = small_img.shape[:2]

        # 缩小到一半加速
        resized = big_img[::2, ::2]
        h, w = resized.shape[:2]
        min_side = int(min(sw, sh) * 0.5 * 0.5)

        # 量化颜色，编码为单通道整数
        q = (resized.astype(np.int32) // 4) * 4
        color_id = q[:, :, 0] + q[:, :, 1] * 256 + q[:, :, 2] * 65536

        flat_colors = color_id.ravel()
        unique, counts = np.unique(flat_colors, return_counts=True)
        top_indices = np.argsort(counts)[-5:]

        best_area = 0
        best_x = 0

        for idx in top_indices:
            c = unique[idx]
            mask = color_id == c
            col_run = np.zeros((h, w), dtype=np.int32)
            col_run[0] = mask[0].astype(np.int32)
            for y in range(1, h):
                col_run[y] = np.where(mask[y], col_run[y - 1] + 1, 0)

            for y in range(min_side, h):
                row = col_run[y] >= min_side
                if not np.any(row):
                    continue
                d = np.diff(row.astype(np.int8))
                starts = np.where(d == 1)[0] + 1
                ends = np.where(d == -1)[0] + 1
                if row[0]:
                    starts = np.concatenate([[0], starts])
                if row[-1]:
                    ends = np.concatenate([ends, [w]])
                for s, e in zip(starts, ends):
                    run_w = e - s
                    if s <= sw // 4:
                        continue
                    run_h = int(col_run[y, s])
                    ratio = run_w / run_h if run_h > 0 else 0
                    if 0.7 < ratio < 1.4 and run_w * run_h > best_area:
                        best_area = run_w * run_h
                        best_x = s

        if best_area == 0:
            return False, "未找到缺口"
        offset_x = best_x * 2
        return True, offset_x

    def _solve_captcha(self):
        """完整验证码流程：获取 → 识别 → 提交 → 返回 (uuid, sign)，失败重试一次"""
        if self._captcha_sign and self._captcha_sign_expire > int(time.time() * 1000):
            return self._captcha_uuid, self._captcha_sign

        for attempt in range(2):
            try:
                token = self._get_token()

                # 1. 获取验证码图片
                client_uid_data = json.dumps({"clientUid": self._gen_client_uid()})
                cap_headers = {
                    "User-Agent": UA,
                    "Origin": "https://beian.miit.gov.cn",
                    "Referer": "https://beian.miit.gov.cn/",
                    "Accept": "application/json, text/plain, */*",
                    "Content-Type": "application/json",
                    "token": token,
                    "Content-Length": str(len(client_uid_data.encode("utf-8"))),
                }
                resp_text = _http_post(CAPTCHA_IMAGE_URL, data=client_uid_data, headers=cap_headers)
                cap_result = json.loads(resp_text)

                if not cap_result.get("success"):
                    raise RuntimeError(f"获取验证码失败: {cap_result.get('msg')}")

                p_uuid = cap_result["params"]["uuid"]
                big_image = cap_result["params"]["bigImage"]
                small_image = cap_result["params"]["smallImage"]

                # 2. 滑块匹配
                match_success, offset = self._match_slider_offset(small_image, big_image)
                if not match_success:
                    raise RuntimeError(f"滑块匹配失败: {offset}")

                # 3. 提交验证结果
                check_data = json.dumps({"key": p_uuid, "value": str(offset)})
                cap_headers["Content-Length"] = str(len(check_data.encode("utf-8")))
                check_resp = _http_post(CAPTCHA_CHECK_URL, data=check_data, headers=cap_headers)
                check_result = json.loads(check_resp)

                if not check_result.get("success"):
                    raise RuntimeError(f"验证码校验失败: {check_result.get('msg')}")

                # 4. 缓存 sign
                self._captcha_uuid = p_uuid
                self._captcha_sign = check_result["params"]
                self._captcha_sign_expire = int(time.time() * 1000) + 300000  # 5分钟
                return p_uuid, self._captcha_sign

            except RuntimeError:
                if attempt == 1:
                    raise

    # ════════════════════════════════════
    # 查询头构造
    # ════════════════════════════════════
    def _build_query_headers(self):
        """构造查询请求头（含验证码 token）"""
        token = self._get_token()
        p_uuid, sign = self._solve_captcha()

        headers = {
            "User-Agent": UA,
            "Origin": "https://beian.miit.gov.cn",
            "Referer": "https://beian.miit.gov.cn/",
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json",
            "token": token,
            "uuid": p_uuid,
            "sign": sign,
        }
        return headers

    # ════════════════════════════════════
    # 普通备案查询
    # ════════════════════════════════════
    def query(self, unit_name, query_type="web", page_num="", page_size=""):
        """
        查询 ICP 备案信息
        参数:
            unit_name: 主办单位名称
            query_type: 查询类型 (web/app/mini/kuai)
            page_num: 页码
            page_size: 每页条数（最大26）
        返回:
            dict: {"success": bool, "total": int, "list": [...]}
        """
        if query_type not in QUERY_TYPE_MAP:
            raise ValueError(f"不支持的查询类型: {query_type}，可选: {list(QUERY_TYPE_MAP.keys())}")

        service_type = QUERY_TYPE_MAP[query_type]["serviceType"]
        info = {
            "pageNum": str(page_num) if page_num else "",
            "pageSize": str(page_size) if page_size else "",
            "unitName": unit_name,
            "serviceType": service_type,
        }

        headers = self._build_query_headers()
        body = json.dumps(info, ensure_ascii=False)
        headers["Content-Length"] = str(len(body.encode("utf-8")))

        resp_text = _http_post(f"{QUERY_URL}/", data=body, headers=headers)

        if "当前访问疑似黑客攻击" in resp_text:
            raise RuntimeError("当前访问已被创宇盾拦截，请更换IP后重试")

        result = json.loads(resp_text)

        # 验证码模式返回 code:200，非验证码模式返回 success:true
        if not (result.get("success") or result.get("code") == 200):
            return {"success": False, "total": 0, "list": [],
                    "message": result.get("msg", "查询失败")}

        items = result.get("params", {}).get("list", [])
        total = result.get("params", {}).get("total", 0)

        if query_type in ("app", "mini", "kuai") and items:
            items = self._fetch_details(items, service_type, headers)

        return {"success": True, "total": total,
                "list": self._normalize_items(items, query_type)}

    # ════════════════════════════════════
    # 违法违规查询
    # ════════════════════════════════════
    def query_blacklist(self, name, query_type="web"):
        """查询违法违规域名/APP/小程序/快应用"""
        if query_type not in BLACK_TYPE_MAP:
            raise ValueError(f"不支持的查询类型: {query_type}")

        service_type = BLACK_TYPE_MAP[query_type]["serviceType"]
        if query_type == "web":
            info = {"domainName": name}
        else:
            info = {"serviceName": name, "serviceType": service_type}

        headers = self._build_query_headers()
        body = json.dumps(info, ensure_ascii=False)
        headers["Content-Length"] = str(len(body.encode("utf-8")))

        url = BLACK_QUERY_URL if query_type == "web" else BLACK_APP_MINI_URL
        resp_text = _http_post(f"{url}/", data=body, headers=headers)

        if "当前访问疑似黑客攻击" in resp_text:
            raise RuntimeError("当前访问已被创宇盾拦截，请更换IP后重试")

        result = json.loads(resp_text)
        if not (result.get("success") or result.get("code") == 200):
            return {"success": False, "total": 0, "list": [],
                    "message": result.get("msg", "查询失败")}

        items = result.get("params", {}).get("list", [])
        total = result.get("params", {}).get("total", 0)
        return {"success": True, "total": total,
                "list": self._normalize_items(items, "black_" + query_type)}

    # ════════════════════════════════════
    # 详情获取（APP/小程序/快应用）
    # ════════════════════════════════════
    def _fetch_detail(self, data_id, service_type, headers):
        info = {"dataId": data_id, "serviceType": service_type}
        body = json.dumps(info, ensure_ascii=False)
        h = headers.copy()
        h["Content-Length"] = str(len(body.encode("utf-8")))
        try:
            resp_text = _http_post(f"{DETAIL_URL}/", data=body, headers=h)
            result = json.loads(resp_text)
            if result.get("success") or result.get("code") == 200:
                return result.get("params", {})
        except Exception:
            pass
        return None

    def _fetch_details(self, items, service_type, base_headers):
        if not items:
            return items
        max_concurrency = min(self._detail_concurrency, len(items), 20)
        detailed = []
        with ThreadPoolExecutor(max_workers=max_concurrency) as executor:
            futures = {}
            for item in items:
                data_id = item.get("dataId")
                if not data_id:
                    detailed.append(item)
                    continue
                future = executor.submit(self._fetch_detail, data_id, service_type, base_headers)
                futures[future] = item
            for future in as_completed(futures):
                item = futures[future]
                try:
                    detail = future.result()
                    detailed.append(detail if detail else item)
                except Exception:
                    detailed.append(item)
        return detailed

    # ════════════════════════════════════
    # 结果标准化
    # ════════════════════════════════════
    def _normalize_items(self, items, query_type):
        result = []
        for item in items:
            row = {
                "unitName": item.get("unitName", ""),
                "serviceName": item.get("serviceName", "") or item.get("domain", ""),
                "serviceLicence": item.get("serviceLicence", ""),
                "contentTypeName": item.get("contentTypeName", ""),
                "leaderName": item.get("leaderName", ""),
                "updateRecordTime": item.get("updateRecordTime", ""),
                "limitAccess": item.get("limitAccess", ""),
                "domain": item.get("domain", ""),
                "mainId": item.get("mainId", ""),
                "serviceType": item.get("serviceType", ""),
                "mainLicence": item.get("mainLicence", ""),
                "natureName": item.get("natureName", ""),
                "illegalType": item.get("illegalType", ""),
                "illegalContent": item.get("illegalContent", ""),
                "punishDate": item.get("punishDate", ""),
                "punishResult": item.get("punishResult", ""),
                "webSite": item.get("webSite", ""),
            }
            result.append(row)
        return result

    # ════════════════════════════════════
    # 便捷方法
    # ════════════════════════════════════
    def query_website(self, name):
        return self.query(name, "web")

    def query_app(self, name):
        return self.query(name, "app")

    def query_mini_app(self, name):
        return self.query(name, "mini")

    def query_kuai_app(self, name):
        return self.query(name, "kuai")

    def query_blacklist_web(self, domain):
        return self.query_blacklist(domain, "web")

    def query_blacklist_app(self, name):
        return self.query_blacklist(name, "app")


if __name__ == "__main__":
    engine = IcpQueryEngine()
    try:
        print("=" * 80)
        print("ICP备案查询 - 网站")
        print("=" * 80)
        result = engine.query_website("深圳市腾讯计算机系统有限公司")
        if result["success"]:
            print(f"共 {result['total']} 条记录，返回 {len(result['list'])} 条")
            for i, item in enumerate(result["list"][:5]):
                print(f"\n  [{i+1}] {item['unitName']}")
                print(f"      域名: {item['serviceName']}")
                print(f"      备案号: {item['serviceLicence']}")
                print(f"      类型: {item['contentTypeName']}")
                print(f"      审核日期: {item['updateRecordTime']}")
        else:
            print(f"查询失败: {result.get('message')}")
    except Exception as e:
        print(f"错误: {e}")
