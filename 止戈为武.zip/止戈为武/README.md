# 止戈为武

PassionSec 网络空间资产测绘工具，聚合多引擎查询、批量采集、端口扫描、资产去重合并等功能。

## 支持引擎

| 引擎 | 说明 |
|------|------|
| FOFA | fofa.info |
| Hunter | 鹰图平台 |
| Quake | 360 Quake |
| ZoomEye | 知道创宇 |
| 0.zone | 零零信安 |

## 安装

```bash
pip install -r requirements.txt
```

依赖：
- `openpyxl` — Excel 读写
- `mmh3` — Icon Hash 计算
- `paramiko` — SSH 远程端口扫描

## 配置

首次使用前编辑 `config.json`，填入各引擎 API Key：

```json
{
  "fofa": {
    "email": "your_email",
    "key": "your_api_key",
    "url": "https://fofa.info",
    "size": 50,
    "maxsize": 10000
  },
  "hunter": {
    "apikey": "your_api_key",
    "size": 50,
    "maxsize": 10000
  },
  "quake": {
    "apikey": "your_api_key",
    "size": 50,
    "maxsize": 10000
  },
  "zoomeye": {
    "apikey": "your_api_key",
    "maxsize": 10000
  },
  "zerokey": {
    "zone_key_id": "your_api_key",
    "size": 100,
    "maxsize": 10000
  },
  "proxy": {
    "ip": "127.0.0.1",
    "port": 7890,
    "proxytype": "HTTP",
    "username": "",
    "password": "",
    "isrun": false
  },
  "ssh": {
    "host": "your_server_ip",
    "port": 22,
    "username": "root",
    "password": "your_password",
    "work_dir": "/path/to/rustscan"
  }
}
```

## 使用方式

### GUI 模式

```bash
python main.py
python main.py gui
```

或双击 `启动止戈为武.bat`。

### CLI 模式

#### 单引擎查询

```bash
python main.py FOFA 'domain="baidu.com"'
python main.py Hunter 'ip="1.1.1.1"' --full
python main.py Quake 'domain:"example.com"' --page 2
```

参数：
- `--full` — 查询全部时间范围（默认近一年）
- `--page N` — 指定页码
- `--export` — 查询结果导出为 xlsx

#### 批量查询

```bash
python main.py --multi FOFA queries.txt --max 500
```

`queries.txt` 每行一条查询语法，`--max` 指定每条最大采集数量。

#### Icon Hash 计算

```bash
python main.py --icon-url https://example.com/favicon.ico
python main.py --icon-file ./favicon.ico
```

输出 FOFA / Hunter / Quake 三种格式的 icon_hash 查询语法。

#### 语法速查

```bash
python main.py --syntax
```

显示各引擎查询语法对照表。

#### 端口扫描（SSH 远程 rustscan）

```bash
python main.py --scan targets.txt
python main.py --scan targets.txt --cmd 'ulimit -n 65535 && ./rustscan -a "$(paste -sd, targets.txt)" -- -sV | tee ports_services.txt'
```

通过 SSH 连接云服务器执行 rustscan，`targets.txt` 每行一个 IP。需要在 `config.json` 中配置 SSH 连接信息。

#### 去重合并

```bash
python main.py --dedup file1.xlsx file2.xlsx
python main.py --dedup file1.xlsx file2.xlsx --domain baidu.com,qq.com
```

合并多个查询结果 xlsx 文件，按（域名、IP、端口）去重。`--domain` 可筛选指定主域名及其子域名。

## GUI 功能

- **单引擎查询** — 选择引擎、输入语法、翻页浏览
- **批量查询** — 多引擎并发采集，支持占位符模板（{domain}、{name}、{title}、{body}、{icp}）
- **Icon Hash** — URL 或本地文件计算 icon hash
- **端口扫描** — SSH 远程调用 rustscan，支持从查询结果或 Excel 导入 IP
- **去重合并** — 多文件合并去重、域名筛选、导出
- **代理设置** — HTTP/SOCKS 代理支持
- **导出** — 查询结果导出为 xlsx，保存到 `result/` 目录

## 目录结构

```
止戈为武/
├── main.py            # 入口（CLI + GUI）
├── nssm_engine.py     # 搜索引擎核心模块
├── nssm_gui.py        # GUI 界面
├── config.json        # 配置文件（API Key、SSH、代理）
├── requirements.txt   # Python 依赖
├── 启动止戈为武.bat    # Windows 快捷启动
├── 止戈_512x512.ico   # 图标
└── result/            # 查询结果输出目录
```

## 注意事项

- 各引擎 API 有调用频率和配额限制，请合理使用
- 端口扫描功能需要云服务器已安装 rustscan
- 代理仅对引擎 API 请求生效
- 所有查询结果默认保存在 `result/` 目录下
