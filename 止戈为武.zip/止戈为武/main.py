"""
止戈为武 - PassionSec - 命令行版 + GUI 入口
用法:
  python main.py                    # 启动 GUI
  python main.py gui                # 启动 GUI
  python main.py FOFA 'domain="baidu.com"'    # CLI 查询
  python main.py Hunter 'ip="1.1.1.1"' --full  # 全部时间
  python main.py FOFA 'title="后台"' --export  # 查询并导出
  python main.py FOFA 'domain="baidu.com"' --page 2  # 指定页码
  python main.py --icon-url https://example.com/favicon.ico  # 计算 icon hash
  python main.py --icon-file ./favicon.ico     # 本地文件计算 icon hash
  python main.py --syntax                      # 查看语法速查表
  python main.py --multi FOFA queries.txt --max 500  # 批量查询
  python main.py --scan targets.txt            # 端口扫描（SSH远程rustscan）
  python main.py --scan targets.txt --cmd 'ulimit -n 65535 && ./rustscan -a "$(paste -sd, targets.txt)" -- -sV | tee ports_services.txt'
  python main.py --dedup file1.xlsx file2.xlsx  # 去重合并
  python main.py --dedup file1.xlsx --domain baidu.com,qq.com  # 去重合并+域名筛选
  python main.py --brute /path/to/scan.sh targets.txt [--root-password xxx]  # 暴力扫描（SSH远程执行脚本，su提权）
  python main.py --icp 深圳市腾讯计算机系统有限公司                  # ICP备案查询（网站）
  python main.py --icp 腾讯 --type app                               # ICP备案查询（APP）
  python main.py --icp 腾讯 --type mini --export                     # ICP备案查询（小程序）并导出
  python main.py --icp baidu.com --black                             # 违法违规域名查询
"""
import base64
import csv
import json
import os
import re
import shlex
import sys
import time
from datetime import datetime

from nssm_engine import (
    NssmSearchEngine, ENGINE_TYPES, NSSM_CONFIG,
    fetch_icon_hash_from_url, fetch_icon_hash_from_file,
    calc_icon_hash, format_host_url
)
from icp_query import IcpQueryEngine, QUERY_TYPE_MAP, BLACK_TYPE_MAP

try:
    import paramiko
except ImportError:
    paramiko = None

try:
    from openpyxl import Workbook, load_workbook
except ImportError:
    Workbook = None
    load_workbook = None

CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
RESULT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "result")


def load_config():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def print_results(results, total, engine, query):
    print(f"\n{'='*100}")
    print(f"  引擎: {engine}  |  查询: {query}  |  共 {total} 条  |  返回 {len(results)} 条")
    print(f"{'='*100}")
    print(f"{'#':<5}{'HOST/URL':<40}{'标题':<25}{'IP':<18}{'端口':<7}{'协议':<7}{'城市':<10}")
    print("-" * 100)
    for i, r in enumerate(results):
        host = format_host_url(r.host, r.protocol, r.port)
        host = host[:38] if host else ""
        title = r.title[:23] if r.title else ""
        ip = r.ip[:16] if r.ip else ""
        print(f"{i+1:<5}{host:<40}{title:<25}{ip:<18}{r.port:<7}{r.protocol:<7}{r.city:<10}")


def export_csv(results, engine, query):
    os.makedirs(RESULT_DIR, exist_ok=True)
    now = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = os.path.join(RESULT_DIR, f"nssm_{engine}_{now}.csv")
    with open(filename, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["#", "HOST", "标题", "IP", "域名", "端口", "协议", "服务指纹", "城市", "ICP备案"])
        for i, r in enumerate(results):
            host = format_host_url(r.host, r.protocol, r.port)
            w.writerow([i+1, host, r.title, r.ip, r.domain, r.port, r.protocol, r.server, r.city, r.icp])
    print(f"\n已导出: {filename}")
    return filename


def export_xlsx(results, engine, query):
    """导出为 xlsx 格式"""
    os.makedirs(RESULT_DIR, exist_ok=True)
    now = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = os.path.join(RESULT_DIR, f"nssm_{engine}_{now}.xlsx")
    wb = Workbook()
    ws = wb.active
    ws.title = "查询结果"
    ws.append([f"[{engine}] {query}"])
    ws.append(["序号", "HOST", "标题", "IP", "域名", "端口", "协议", "服务指纹", "城市", "ICP备案"])
    for i, r in enumerate(results):
        host = format_host_url(r.host, r.protocol, r.port)
        ws.append([i + 1, host, r.title, r.ip, r.domain, r.port,
                   r.protocol, r.server, r.city, r.icp])
    wb.save(filename)
    print(f"\n已导出: {filename}")
    return filename


def print_syntax_table():
    print(f"\n{'='*90}")
    print("  查询语法速查表")
    print(f"{'='*90}")
    print(f"{'语法名称':<14}{'FOFA':<35}{'Hunter':<35}")
    print("-" * 90)
    for row in NSSM_CONFIG:
        name = row["name"]
        fofa = row["fofa"][:33]
        hunter = row["hunter"][:33]
        print(f"{name:<14}{fofa:<35}{hunter:<35}")
    print(f"{'='*90}")
    print(f"{'语法名称':<14}{'Quake':<35}{'ZoomEye':<35}{'0.zone':<35}")
    print("-" * 90)
    for row in NSSM_CONFIG:
        name = row["name"]
        quake = row["quake"][:33]
        zoomeye = row["zoomeye"][:33]
        zero = row["zero"][:33]
        print(f"{name:<14}{quake:<35}{zoomeye:<35}{zero:<35}")


def do_portscan(args):
    """端口扫描: 通过 SSH 调用远程 rustscan"""
    cfg = load_config()
    if paramiko is None:
        print("错误: paramiko 未安装")
        return
    ssh_cfg = cfg.get("ssh", {})
    if not ssh_cfg.get("host") or not ssh_cfg.get("username"):
        print("错误: 请先在 config.json 中配置 SSH 连接信息")
        print('  "ssh": {"host": "x.x.x.x", "port": 22, "username": "root", "password": "xxx", "work_dir": "/root/rustscan"}')
        return

    # 解析参数
    targets_file = args[0] if args else None
    if not targets_file or not os.path.exists(targets_file):
        print(f"错误: 目标文件不存在: {targets_file}")
        print("用法: python main.py --scan targets.txt")
        return

    # 读取 IP 列表
    with open(targets_file, "r", encoding="utf-8") as f:
        ips = [l.strip() for l in f if l.strip()]
    if not ips:
        print("错误: 目标文件为空")
        return

    # 自定义命令
    default_cmd = 'ulimit -n 65535 && ./rustscan -a "$(paste -sd, targets.txt)" -- -sV | tee ports_services.txt'
    scan_cmd = default_cmd
    if "--cmd" in sys.argv:
        cmd_idx = sys.argv.index("--cmd")
        if cmd_idx + 1 < len(sys.argv):
            scan_cmd = sys.argv[cmd_idx + 1]

    work_dir = ssh_cfg.get("work_dir", "/root")

    print(f"[1/3] 连接 SSH: {ssh_cfg['host']}:{ssh_cfg.get('port', 22)}")
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh.connect(ssh_cfg["host"], port=int(ssh_cfg.get("port", 22)),
                    username=ssh_cfg["username"], password=ssh_cfg.get("password", ""),
                    timeout=15)
    except Exception as e:
        print(f"SSH 连接失败: {e}")
        return

    print(f"[2/3] 写入 {len(ips)} 个目标到 {work_dir}/targets.txt")
    targets_content = "\n".join(ips)
    b64 = base64.b64encode(targets_content.encode()).decode()
    write_cmd = f"echo {b64} | base64 -d > {work_dir}/targets.txt"
    stdin, stdout, stderr = ssh.exec_command(write_cmd)
    stdout.read()

    print(f"[3/3] 执行扫描: {scan_cmd}")
    full_cmd = f"cd {work_dir} && {scan_cmd}"
    stdin, stdout, stderr = ssh.exec_command(full_cmd, timeout=600)

    # 实时输出
    for line in iter(stdout.readline, ""):
        print(f"  {line.rstrip()}")

    exit_status = stdout.channel.recv_exit_status()
    if exit_status != 0:
        print(f"⚠ 扫描退出码: {exit_status}")
        err_output = stderr.read().decode('utf-8', errors='ignore')
        if err_output.strip():
            print(f"  stderr: {err_output.strip()}")

    # 读取结果
    print(f"\n读取结果: {work_dir}/ports_services.txt")
    stdin, stdout, stderr = ssh.exec_command(f"cat {work_dir}/ports_services.txt")
    result_content = stdout.read().decode('utf-8', errors='ignore')
    ssh.close()

    if result_content.strip():
        # 解析并显示
        current_ip = None
        count = 0
        print(f"\n{'='*80}")
        print(f"{'IP':<18}{'端口':<12}{'状态':<10}{'服务/版本'}")
        print("-" * 80)
        for line in result_content.split("\n"):
            line = line.strip()
            ip_match = re.search(r'Nmap scan report for (?:\S+ \()?(\d+\.\d+\.\d+\.\d+)', line)
            if ip_match:
                current_ip = ip_match.group(1)
                continue
            port_match = re.match(r'(\d+)/(tcp|udp)\s+(open|closed|filtered)\s+(\S+)(?:\s+(.+))?', line)
            if port_match and current_ip:
                port = port_match.group(1)
                proto = port_match.group(2)
                status = port_match.group(3)
                service = port_match.group(4)
                version = port_match.group(5) or ""
                if status == "open":
                    print(f"{current_ip:<18}{port}/{proto:<10}{status:<10}{service} {version}")
                    count += 1
        print(f"{'='*80}")
        print(f"扫描完成: 发现 {count} 个开放端口")
    else:
        print("⚠ 结果文件为空")


def do_dedup(args):
    """去重合并 xlsx 文件"""
    # 解析参数
    files = []
    main_domains = []
    i = 0
    while i < len(args):
        if args[i] == "--domain" and i + 1 < len(args):
            main_domains = [d.strip() for d in args[i + 1].split(",") if d.strip()]
            i += 2
        else:
            filepath = args[i]
            if not os.path.isabs(filepath):
                filepath = os.path.join(RESULT_DIR, filepath)
            if os.path.exists(filepath):
                files.append(filepath)
            else:
                print(f"⚠ 文件不存在: {filepath}")
            i += 1

    if not files:
        print("错误: 没有有效的 xlsx 文件")
        print("用法: python main.py --dedup file1.xlsx file2.xlsx --domain baidu.com,qq.com")
        return

    # 读取所有文件
    all_rows = []
    for filepath in files:
        try:
            wb = load_workbook(filepath, read_only=True)
            ws = wb.active
            header_row = None
            for row_idx, row in enumerate(ws.iter_rows(values_only=True), 1):
                if row and any("HOST" in str(c).upper() or "IP" in str(c).upper() for c in row if c):
                    header_row = [str(c).strip() if c else "" for c in row]
                    break
            if not header_row:
                wb.close()
                continue
            for row in ws.iter_rows(min_row=row_idx + 1, values_only=True):
                if not row or not any(row):
                    continue
                row_dict = {}
                for ci, val in enumerate(row):
                    if ci < len(header_row):
                        row_dict[header_row[ci]] = str(val).strip() if val else ""
                all_rows.append(row_dict)
            wb.close()
            print(f"  读取: {os.path.basename(filepath)} ({len(all_rows)} 条)")
        except Exception as e:
            print(f"  ⚠ 读取失败 {filepath}: {e}")

    print(f"\n合并 {len(all_rows)} 条")

    # 去重
    DEDUP_KEYS = ("域名", "IP", "端口")
    seen = {}
    deduped = []
    for r in all_rows:
        key = tuple(r.get(k, "").lower() for k in DEDUP_KEYS)
        if key not in seen:
            seen[key] = r
            deduped.append(r)
        else:
            # 合并服务指纹
            existing = seen[key]
            existing_fp = existing.get("服务指纹", "")
            new_fp = r.get("服务指纹", "")
            if new_fp and new_fp not in existing_fp:
                existing["服务指纹"] = (existing_fp + " | " + new_fp) if existing_fp else new_fp

    print(f"去重后 {len(deduped)} 条")

    # 域名筛选
    if main_domains:
        filtered = []
        for r in deduped:
            domain = r.get("域名", "").lower()
            if domain:
                if any(domain == md.lower() or domain.endswith("." + md.lower()) for md in main_domains):
                    filtered.append(r)
            else:
                filtered.append(r)
        deduped = filtered
        print(f"筛选后 {len(deduped)} 条 (域名: {', '.join(main_domains)})")

    # 导出
    os.makedirs(RESULT_DIR, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_path = os.path.join(RESULT_DIR, f"合并去重_资产测绘_{ts}.xlsx")

    wb = Workbook()
    ws = wb.active
    ws.title = "合并去重"
    out_cols = ["序号", "HOST", "标题", "IP", "域名", "端口", "协议", "服务指纹", "城市", "ICP备案"]
    ws.append(out_cols)
    for i, r in enumerate(deduped, 1):
        ws.append([i, r.get("HOST", ""), r.get("标题", ""), r.get("IP", ""),
                   r.get("域名", ""), r.get("端口", ""), r.get("协议", ""),
                   r.get("服务指纹", ""), r.get("城市", ""), r.get("ICP备案", "")])
    wb.save(output_path)
    print(f"\n已导出: {output_path}")


def do_brutescan(args):
    """暴力扫描: 通过 SSH 上传 targets.txt 并执行远程脚本（su 提权）"""
    if paramiko is None:
        print("错误: paramiko 未安装")
        return
    if len(args) < 2:
        print("用法: python main.py --brute /path/to/scan.sh targets.txt [--root-password xxx]")
        print("  参数1: 远程 .sh 脚本的绝对路径")
        print("  参数2: 本地 targets.txt 文件路径")
        print("  可选: --root-password xxx  root密码（也可在 config.json brutescan.root_password 中配置）")
        return

    script_path = args[0]
    targets_file = args[1]

    # 解析 root 密码
    root_password = ""
    if "--root-password" in args:
        idx = args.index("--root-password")
        if idx + 1 < len(args):
            root_password = args[idx + 1]

    cfg = load_config()
    if not root_password:
        root_password = cfg.get("brutescan", {}).get("root_password", "")

    if not os.path.exists(targets_file):
        print(f"错误: 目标文件不存在: {targets_file}")
        return

    with open(targets_file, "r", encoding="utf-8") as f:
        targets_content = f.read().strip()
    if not targets_content:
        print("错误: 目标文件为空")
        return

    ssh_cfg = cfg.get("ssh", {})
    if not ssh_cfg.get("host") or not ssh_cfg.get("username"):
        print("错误: 请先在 config.json 中配置 SSH 连接信息")
        return

    work_dir = os.path.dirname(script_path) if "/" in script_path else ssh_cfg.get("work_dir", "/root")

    print(f"[1/4] 连接 SSH: {ssh_cfg['host']}:{ssh_cfg.get('port', 22)}")
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        ssh.connect(ssh_cfg["host"], port=int(ssh_cfg.get("port", 22)),
                    username=ssh_cfg["username"], password=ssh_cfg.get("password", ""),
                    timeout=15)
    except Exception as e:
        print(f"SSH 连接失败: {e}")
        return

    # 写入 targets.txt
    targets_path = f"{work_dir}/targets.txt"
    print(f"[2/4] 写入 targets.txt -> {targets_path}")
    import base64
    b64 = base64.b64encode(targets_content.encode()).decode()
    write_cmd = f"echo {b64} | base64 -d > {targets_path}"
    stdin, stdout, stderr = ssh.exec_command(write_cmd)
    stdout.read()

    # 执行脚本（su 提权）
    print(f"[3/4] su 提权执行脚本: {script_path}")
    inner_cmd = f"cd {work_dir} && bash {script_path}"
    if root_password:
        exec_cmd = f"echo '{shlex.quote(root_password)}' | su -c '{inner_cmd}'"
    else:
        exec_cmd = f"cd {work_dir} && bash {script_path}"
    stdin, stdout, stderr = ssh.exec_command(exec_cmd, timeout=1800)

    # 实时输出
    channel = stdout.channel
    channel.setblocking(0)
    while not channel.exit_status_ready():
        if channel.recv_ready():
            data = channel.recv(4096).decode('utf-8', errors='ignore')
            if data.strip():
                for line in data.strip().split("\n"):
                    print(f"  {line}")
        if channel.recv_stderr_ready():
            err_data = channel.recv_stderr(4096).decode('utf-8', errors='ignore')
            if err_data.strip():
                for line in err_data.strip().split("\n"):
                    print(f"  [stderr] {line}")
        time.sleep(0.05)

    exit_status = channel.recv_exit_status()
    ssh.close()

    if exit_status == 0:
        print("\n执行完成")
    elif exit_status == -1:
        print("\n⚠ 已被用户停止（Ctrl+C）")
    else:
        print(f"\n⚠ 脚本退出码: {exit_status}")


def do_icp_query(args):
    """ICP 备案查询"""
    query_type = "web"
    black = False
    export = False
    name = None

    i = 0
    while i < len(args):
        if args[i] == "--type" and i + 1 < len(args):
            query_type = args[i + 1]
            if query_type not in QUERY_TYPE_MAP:
                print(f"不支持的查询类型: {query_type}")
                print(f"可用类型: {', '.join(QUERY_TYPE_MAP.keys())}")
                return
            i += 2
        elif args[i] == "--black":
            black = True
            i += 1
        elif args[i] == "--export":
            export = True
            i += 1
        elif not args[i].startswith("--") and name is None:
            name = args[i]
            i += 1
        else:
            i += 1

    if not name:
        print("请提供查询关键词")
        print("用法: python main.py --icp <主办单位名称/域名> [--type web|app|mini|kuai] [--black] [--export]")
        return

    print(f"\n{'='*80}")
    label = BLACK_TYPE_MAP[query_type]["name"] if black else QUERY_TYPE_MAP[query_type]["name"]
    print(f"  ICP备案查询 - {label}: {name}")
    print(f"{'='*80}")

    engine = IcpQueryEngine()
    try:
        if black:
            result = engine.query_blacklist(name, query_type)
        else:
            result = engine.query(name, query_type)

        if not result["success"]:
            print(f"查询失败: {result.get('message', '未知错误')}")
            return

        items = result["list"]
        total = result["total"]
        print(f"共 {total} 条记录，返回 {len(items)} 条\n")

        if not items:
            print("  暂无数据")
            return

        # 打印结果表
        if black:
            header = f"{'#':<4}{'域名/服务名':<32}{'违法违规类型':<16}{'处罚日期':<14}{'处罚结果'}"
            print(header)
            print("-" * 100)
            for i, item in enumerate(items):
                name_val = item.get("webSite") or item.get("serviceName", "")
                print(f"{i+1:<4}{name_val[:30]:<32}{item.get('illegalType','')[:14]:<16}"
                      f"{item.get('punishDate','')[:12]:<14}{item.get('punishResult','')}")
        else:
            header = f"{'#':<4}{'主办单位':<24}{'域名/服务名':<30}{'备案号':<22}{'审核日期':<12}{'类型'}"
            print(header)
            print("-" * 120)
            for i, item in enumerate(items):
                print(f"{i+1:<4}{item['unitName'][:22]:<24}{item['serviceName'][:28]:<30}"
                      f"{item['serviceLicence'][:20]:<22}{item['updateRecordTime'][:10]:<12}"
                      f"{item.get('contentTypeName','')}")

        # 导出
        if export:
            _export_icp_csv(items, query_type, name, black)

    except Exception as e:
        print(f"查询出错: {e}")


def _export_icp_csv(items, query_type, name, black):
    """导出 ICP 查询结果为 CSV"""
    os.makedirs(RESULT_DIR, exist_ok=True)
    now = datetime.now().strftime("%Y%m%d_%H%M%S")
    prefix = "icp_black_" if black else "icp_"
    filename = os.path.join(RESULT_DIR, f"{prefix}{query_type}_{now}.csv")
    with open(filename, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        if black:
            w.writerow(["#", "域名/服务名", "违法违规类型", "违法违规内容", "处罚日期", "处罚结果"])
            for i, item in enumerate(items):
                w.writerow([i+1, item.get("webSite") or item.get("serviceName", ""),
                           item.get("illegalType", ""), item.get("illegalContent", ""),
                           item.get("punishDate", ""), item.get("punishResult", "")])
        else:
            w.writerow(["#", "主办单位", "域名/服务名", "备案号", "类型", "负责人", "审核日期", "主体备案号"])
            for i, item in enumerate(items):
                w.writerow([i+1, item["unitName"], item["serviceName"],
                           item["serviceLicence"], item.get("contentTypeName", ""),
                           item.get("leaderName", ""), item["updateRecordTime"],
                           item.get("mainLicence", "")])
    print(f"\n已导出: {filename}")


def main():
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help"):
        print(__doc__)
        print("\n支持引擎:", ", ".join(ENGINE_TYPES))
        print_syntax_table()
        return

    if sys.argv[1] == "gui" or len(sys.argv) == 1:
        from nssm_gui import main as gui_main
        gui_main()
        return

    # --icon-url / --icon-file
    if sys.argv[1] == "--icon-url":
        if len(sys.argv) < 3:
            print("用法: python main.py --icon-url <URL>")
            return
        result = fetch_icon_hash_from_url(sys.argv[2])
        if result:
            print(f"FOFA:   {result['fofa']}")
            print(f"Hunter: {result['hunter']}")
            print(f"Quake:  {result['quake']}")
        else:
            print("获取失败")
        return

    if sys.argv[1] == "--icon-file":
        if len(sys.argv) < 3:
            print("用法: python main.py --icon-file <path>")
            return
        result = fetch_icon_hash_from_file(sys.argv[2])
        if result:
            print(f"FOFA:   {result['fofa']}")
            print(f"Hunter: {result['hunter']}")
            print(f"Quake:  {result['quake']}")
        else:
            print("获取失败")
        return

    # --syntax
    if sys.argv[1] == "--syntax":
        print_syntax_table()
        return

    # --scan 端口扫描
    if sys.argv[1] == "--scan":
        do_portscan(sys.argv[2:])
        return

    # --dedup 去重合并
    if sys.argv[1] == "--dedup":
        do_dedup(sys.argv[2:])
        return

    # --brute 暴力扫描
    if sys.argv[1] == "--brute":
        do_brutescan(sys.argv[2:])
        return

    # --icp ICP备案查询
    if sys.argv[1] == "--icp":
        do_icp_query(sys.argv[2:])
        return

    # 查询模式: python main.py <引擎> <查询语法> [选项]
    engine = sys.argv[1]
    if engine not in ENGINE_TYPES:
        print(f"不支持的引擎: {engine}")
        print(f"可用引擎: {', '.join(ENGINE_TYPES)}")
        return

    query = sys.argv[2] if len(sys.argv) > 2 else ""
    if not query:
        print("请提供查询语法")
        return

    full = "--full" in sys.argv
    export = "--export" in sys.argv
    multi = "--multi" in sys.argv

    cfg = load_config()
    nssm = NssmSearchEngine(cfg)

    if multi:
        # 批量模式：从文件读取
        filepath = sys.argv[sys.argv.index("--multi") + 1] if "--multi" in sys.argv and len(sys.argv) > sys.argv.index("--multi") + 1 else None
        if not filepath:
            print("用法: python main.py FOFA --multi queries.txt --max 500")
            return
        with open(filepath, "r", encoding="utf-8") as f:
            queries = [l.strip() for l in f if l.strip()]
        max_per = 100
        if "--max" in sys.argv:
            max_per = int(sys.argv[sys.argv.index("--max") + 1])
        all_results = nssm.search_multi(engine, queries, max_per, full,
                                        progress_callback=lambda i, t, q, n:
                                        print(f"[{i}/{t}] {q[:40]}... -> {n}条"))
        print_results(all_results, len(all_results), engine, f"批量 {len(queries)} 个关键词")
        if export:
            export_xlsx(all_results, engine, "批量查询")
    else:
        page = 1
        if "--page" in sys.argv:
            page = int(sys.argv[sys.argv.index("--page") + 1])
        results, total, err = nssm.search(engine, query, page, full)
        if err:
            print(f"查询失败: {err}")
            return
        print_results(results, total, engine, query)
        if export:
            export_xlsx(results, engine, query[:20].replace('"', '_'))


if __name__ == "__main__":
    main()
