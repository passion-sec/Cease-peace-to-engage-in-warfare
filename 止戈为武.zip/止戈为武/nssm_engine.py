"""
止戈为武 - PassionSec - 网络空间搜索引擎查询模块
支持: FOFA, Hunter(鹰图), Quake(360), ZoomEye, 0.zone(零零信安)
复刻自密探 mitan 的 NSSM 模块
"""
import base64
import hashlib
import json
import logging
import random
import re
import ssl
import time

_logger = logging.getLogger(__name__)
if not _logger.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter('%(levelname)s:%(name)s: %(message)s'))
    _logger.addHandler(_h)
    _logger.setLevel(logging.INFO)
from datetime import datetime, timedelta
from urllib.request import Request, urlopen, ProxyHandler, build_opener, HTTPSHandler
from urllib.error import URLError
from urllib.parse import urlencode, urlparse, urljoin

try:
    import mmh3
except ImportError:
    mmh3 = None

# ════════════════════════════════════════
# User-Agent 池（取自原版 HttpClientHelper）
# ════════════════════════════════════════
_UA_LIST = [
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 11_1_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.41 Safari/537.36 Edg/88.0.705.22",
    "Mozilla/5.0 (Linux x86_64; rv:91.0) Gecko/20100101 Firefox/91.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 12_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/97.0.4692.99 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:96.0) Gecko/20100101 Firefox/96.0",
]

# ════════════════════════════════════════
# SSL 证书校验绕过（取自原版 TrustModifier）
# ════════════════════════════════════════
_SSL_CONTEXT = ssl.create_default_context()
_SSL_CONTEXT.check_hostname = False
_SSL_CONTEXT.verify_mode = ssl.CERT_NONE


def _random_ua():
    return random.choice(_UA_LIST)


def _encode_base64(text: str) -> str:
    """标准 Base64 编码（FOFA, ZoomEye 用）"""
    return base64.b64encode(text.encode("utf-8")).decode()


def _encode_base64url(text: str) -> str:
    """Base64URL 编码（Hunter 用），去除 = + / 替换"""
    return base64.urlsafe_b64encode(text.encode("utf-8")).decode().rstrip("=")


def _build_opener(proxy_config: dict | None):
    """根据代理配置构建 URL opener（跳过 SSL 证书验证，等同原版 TrustModifier）"""
    # 使用不验证证书的 SSL context
    https_handler = HTTPSHandler(context=_SSL_CONTEXT)
    if proxy_config and proxy_config.get("isrun"):
        ptype = proxy_config.get("proxytype", "HTTP")
        host = proxy_config["ip"]
        port = proxy_config["port"]
        user = proxy_config.get("username", "")
        pwd = proxy_config.get("password", "")
        if ptype == "SOCKS":
            proxy_url = f"socks5://{user}:{pwd}@{host}:{port}" if user else f"socks5://{host}:{port}"
        else:
            proxy_url = f"http://{user}:{pwd}@{host}:{port}" if user else f"http://{host}:{port}"
        proxy_handler = ProxyHandler({ptype.lower(): proxy_url})
        return build_opener(proxy_handler, https_handler)
    return build_opener(https_handler)


def _http_get(url: str, headers: dict | None = None, proxy_config: dict | None = None) -> str:
    """HTTP GET 请求"""
    opener = _build_opener(proxy_config)
    req = Request(url)
    req.add_header("User-Agent", _random_ua())
    req.add_header("Accept-Encoding", "identity")
    if headers:
        for k, v in headers.items():
            req.add_header(k, v)
    try:
        with opener.open(req, timeout=20) as resp:
            return resp.read().decode("utf-8")
    except Exception as e:
        _logger.error("[GET Error] %s: %s", url, e)
        return ""


def _http_post(url: str, data: dict, headers: dict | None = None, proxy_config: dict | None = None) -> str:
    """HTTP POST 请求 (JSON body)"""
    opener = _build_opener(proxy_config)
    body = json.dumps(data).encode("utf-8")
    req = Request(url, data=body)
    req.add_header("User-Agent", _random_ua())
    req.add_header("Content-Type", "application/json")
    if headers:
        for k, v in headers.items():
            req.add_header(k, v)
    try:
        with opener.open(req, timeout=20) as resp:
            return resp.read().decode("utf-8")
    except Exception as e:
        _logger.error("[POST Error] %s: %s", url, e)
        return ""


# ════════════════════════════════════════
# 结果数据类
# ════════════════════════════════════════
class NssmResult:
    """统一查询结果"""
    def __init__(self, host="", title="", ip="", domain="", port=0,
                 protocol="", server="", city="", icp="", **kwargs):
        self.host = host
        self.title = title
        self.ip = ip
        self.domain = domain
        self.port = port
        self.protocol = protocol
        self.server = server
        self.city = city
        self.icp = icp
        self.extra = kwargs  # 0.zone 特有字段

    def to_dict(self):
        return {
            "host": self.host, "title": self.title, "ip": self.ip,
            "domain": self.domain, "port": self.port, "protocol": self.protocol,
            "server": self.server, "city": self.city, "icp": self.icp
        }

    def to_row(self):
        """转为表格行"""
        return [self.host, self.title, self.ip, self.domain, str(self.port),
                self.protocol, self.server, self.city, self.icp]


# ════════════════════════════════════════
# FOFA 引擎
# ════════════════════════════════════════
class FofaClient:
    """FOFA API: GET + email/key 认证 + Base64 查询"""

    SEARCH_PATH = "/api/v1/search/all"
    FIELDS = "host,title,ip,domain,port,protocol,server,city,icp"

    def __init__(self, email="", key="", size=50, maxsize=10000, base_url="https://fofa.info"):
        self.email = email
        self.key = key
        self.size = size
        self.maxsize = maxsize
        self.base_url = base_url.rstrip("/")

    def _build_url(self, page: int, full: bool, multisize: int | None = None) -> str:
        sz = multisize if multisize else self.size
        # fofa.icu 镜像单次最多 50 条，fofa.info 不受此限制
        if "fofa.icu" in self.base_url:
            sz = min(sz, 50)
        params = {
            "email": self.email,
            "key": self.key,
            "full": "true" if full else "false",
            "page": page,
            "size": sz,
            "fields": self.FIELDS,
            "qbase64": "",  # 查询内容拼接在 URL 末尾
        }
        qs = urlencode(params)
        return f"{self.base_url}{self.SEARCH_PATH}?{qs}"

    def _parse_response(self, obj: dict) -> tuple[list[NssmResult], int, str]:
        """解析 FOFA API 响应"""
        if obj.get("error", True):
            return [], 0, obj.get("errmsg", "未知错误")
        total = int(obj.get("size", 0))
        results = []
        for row in obj.get("results", []):
            results.append(NssmResult(
                host=row[0].strip() if row[0] else "",
                title=row[1].strip() if row[1] else "",
                ip=row[2] if row[2] else "",
                domain=row[3] if row[3] else "",
                port=int(row[4]) if row[4] else 0,
                protocol=row[5] if row[5] else "",
                server=row[6] if row[6] else "",
                city=row[7] if row[7] else "",
                icp=row[8] if len(row) > 8 and row[8] else "",
            ))
        return results, total, ""

    def search(self, query: str, page: int = 1, full: bool = False,
               proxy_config: dict | None = None) -> tuple[list[NssmResult], int, str]:
        url = self._build_url(page, full) + _encode_base64(query)
        resp = _http_get(url, proxy_config=proxy_config)
        if not resp:
            return [], 0, "请求失败"
        try:
            return self._parse_response(json.loads(resp))
        except json.JSONDecodeError:
            return [], 0, f"JSON解析失败: {resp[:200]}"

    def search_batch(self, query: str, max_results: int, full: bool = False,
                     proxy_config: dict | None = None) -> tuple[list[NssmResult], int, str]:
        url = self._build_url(1, full, multisize=max_results) + _encode_base64(query)
        resp = _http_get(url, proxy_config=proxy_config)
        if not resp:
            return [], 0, "请求失败"
        try:
            return self._parse_response(json.loads(resp))
        except json.JSONDecodeError:
            return [], 0, "JSON解析失败"


# ════════════════════════════════════════
# Hunter (鹰图) 引擎
# ════════════════════════════════════════
class HunterClient:
    """Hunter API: GET + api-key 认证 + Base64URL 查询 + 多 key 轮转"""

    BASE_URL = "https://hunter.qianxin.com/openApi/search"
    FIELDS = "url,web_title,ip,domain,port,protocol,os,city,number"

    def __init__(self, apikey="", size=50, maxsize=10000):
        self.apikey = apikey  # 支持多 key, 换行分隔
        self.size = size
        self.maxsize = maxsize

    def _get_keys(self) -> list[str]:
        return [k.strip() for k in self.apikey.split("\n") if k.strip()]

    def _build_url(self, page: int, full: bool, key_index: int = 0,
                   multisize: int | None = None) -> str:
        keys = self._get_keys()
        if not keys:
            keys = [""]
        idx = min(key_index, len(keys) - 1)
        hunter_key = keys[idx]
        sz = multisize if multisize else self.size
        params = {
            "api-key": hunter_key,
            "fields": self.FIELDS,
            "page": page,
            "page_size": sz,
            "search": "",  # 拼接在末尾
        }
        if not full:
            now = datetime.now()
            params["start_time"] = (now - timedelta(days=365)).strftime("%Y-%m-%d")
            params["end_time"] = now.strftime("%Y-%m-%d")
        qs = urlencode(params)
        return f"{self.BASE_URL}?{qs}"

    def _search_with_key(self, query: str, page: int, full: bool,
                         key_index: int, proxy_config: dict | None,
                         multisize: int | None = None) -> tuple[list[NssmResult], int, str, int]:
        """返回增加 key_index，支持 40204 自动切换"""
        url = self._build_url(page, full, key_index, multisize) + _encode_base64url(query)
        resp = _http_get(url, proxy_config=proxy_config)
        if not resp:
            return [], 0, "请求失败", key_index

        try:
            obj = json.loads(resp)
        except json.JSONDecodeError:
            return [], 0, f"JSON解析失败", key_index

        code = str(obj.get("code", ""))
        if code == "40204":
            keys = self._get_keys()
            if key_index >= len(keys) - 1:
                return [], 0, obj.get("message", "配额已用完"), key_index
            time.sleep(0.5)
            return self._search_with_key(query, page, full, key_index + 1, proxy_config, multisize)

        if code != "200":
            return [], 0, obj.get("message", "未知错误"), key_index

        data = obj.get("data", {})
        total = int(data.get("total", 0))
        results = []
        for item in data.get("arr", []):
            results.append(NssmResult(
                host=item.get("url", "").strip(),
                title=item.get("web_title", "").strip(),
                ip=item.get("ip", ""),
                domain=item.get("domain", ""),
                port=int(item.get("port", 0)),
                protocol=item.get("protocol", ""),
                server=item.get("os", ""),
                city=item.get("city", ""),
                icp=item.get("number", ""),
            ))
        return results, total, "", key_index

    def search(self, query: str, page: int = 1, full: bool = False,
               proxy_config: dict | None = None) -> tuple[list[NssmResult], int, str]:
        results, total, err, _ = self._search_with_key(query, page, full, 0, proxy_config)
        return results, total, err

    def search_batch(self, query: str, max_results: int, full: bool = False,
                     proxy_config: dict | None = None) -> tuple[list[NssmResult], int, str]:
        results, total, err, _ = self._search_with_key(query, 1, full, 0, proxy_config,
                                                       multisize=max_results)
        return results, total, err


# ════════════════════════════════════════
# Quake (360) 引擎
# ════════════════════════════════════════
class QuakeClient:
    """Quake API: POST + X-QuakeToken Header + JSON body"""

    BASE_URL = "https://quake.360.net/api/v3/search/quake_service"
    INCLUDE = ["ip", "port", "hostname", "transport", "service.http.host",
               "service.http.title", "service.http.server", "service.name", "location.city_cn"]

    def __init__(self, apikey="", size=50, maxsize=10000):
        self.apikey = apikey
        self.size = size
        self.maxsize = maxsize

    def _build_body(self, query: str, page: int, full: bool,
                    multisize: int | None = None) -> dict:
        sz = multisize if multisize else self.size
        start = (page - 1) * sz
        body = {
            "query": query,
            "start": start,
            "size": sz,
            "ignore_cache": "False",
            "latest": "True",
            "include": self.INCLUDE,
            "shortcuts": ["610ce2adb1a2e3e1632e67b1"],
        }
        if not full:
            now = datetime.now()
            body["start_time"] = (now - timedelta(days=365)).strftime("%Y-%m-%d 00:00:00")
            body["end_time"] = now.strftime("%Y-%m-%d 00:00:00")
        return body

    def _parse_response(self, obj: dict) -> tuple[list[NssmResult], int, str]:
        """解析 Quake API 响应"""
        if obj.get("code") != 0:
            return [], 0, obj.get("message", "未知错误")
        meta = obj.get("meta", {})
        total = int(meta.get("pagination", {}).get("total", 0))
        results = []
        for item in obj.get("data", []):
            service = item.get("service", {})
            http = service.get("http", {}) or {}
            location = item.get("location", {})
            host = http.get("host", "")
            domain = ""
            if host and not _is_ip(host):
                domain = host
            results.append(NssmResult(
                host=host,
                title=http.get("title", "").strip(),
                ip=item.get("ip", ""),
                domain=domain,
                port=int(item.get("port", 0)),
                protocol=service.get("name", ""),
                server=http.get("server", ""),
                city=location.get("city_cn", ""),
                icp=location.get("icp", ""),
            ))
        return results, total, ""

    def search(self, query: str, page: int = 1, full: bool = False,
               proxy_config: dict | None = None) -> tuple[list[NssmResult], int, str]:
        body = self._build_body(query, page, full)
        headers = {"X-QuakeToken": self.apikey}
        resp = _http_post(self.BASE_URL, body, headers, proxy_config)
        if not resp:
            return [], 0, "请求失败"
        try:
            return self._parse_response(json.loads(resp))
        except json.JSONDecodeError:
            return [], 0, "JSON解析失败"

    def search_batch(self, query: str, max_results: int, full: bool = False,
                     proxy_config: dict | None = None) -> tuple[list[NssmResult], int, str]:
        body = self._build_body(query, 1, full, multisize=max_results)
        headers = {"X-QuakeToken": self.apikey}
        resp = _http_post(self.BASE_URL, body, headers, proxy_config)
        if not resp:
            return [], 0, "请求失败"
        try:
            return self._parse_response(json.loads(resp))
        except json.JSONDecodeError:
            return [], 0, "JSON解析失败"


# ════════════════════════════════════════
# ZoomEye 引擎
# ════════════════════════════════════════
class ZoomEyeClient:
    """ZoomEye API: POST + API-KEY Header + JSON body (qbase64)"""

    BASE_URL = "https://api.zoomeye.org/v2/search"
    FIELDS = "ip,port,os,title,hostname,domain,service,city.name"

    def __init__(self, apikey="", size=100, maxsize=10000):
        self.apikey = apikey
        self.size = size
        self.maxsize = maxsize

    def search(self, query: str, page: int = 1, full: bool = False,
               proxy_config: dict | None = None) -> tuple[list[NssmResult], int, str]:
        # ZoomEye POST 需要 qbase64 编码
        if not full:
            start_time = (datetime.now() - timedelta(days=365)).strftime("%Y-%m-%d")
            query = f'{query} +after:"{start_time}"'
        body = {
            "qbase64": _encode_base64(query),
            "page": page,
            "pagesize": self.size,
            "fields": self.FIELDS,
            "sub_type": "web",
        }
        headers = {"API-KEY": self.apikey}
        resp = _http_post(self.BASE_URL, body, headers, proxy_config)
        if not resp:
            return [], 0, "请求失败"
        try:
            obj = json.loads(resp)
        except json.JSONDecodeError:
            return [], 0, f"JSON解析失败"

        code = str(obj.get("code", ""))
        if code != "60000":
            return [], 0, obj.get("message", "未知错误")

        total = int(obj.get("total", 0))
        results = []
        for item in obj.get("data", []):
            city_name = ""
            city_obj = item.get("city", {})
            if isinstance(city_obj, dict):
                city_name = city_obj.get("name", "")
            results.append(NssmResult(
                host=item.get("hostname", ""),
                title=item.get("title", ""),
                ip=item.get("ip", ""),
                domain=item.get("domain", ""),
                port=int(item.get("port", 0)),
                protocol=item.get("service", ""),
                server=item.get("os", ""),
                city=city_name,
            ))
        return results, total, ""

    def search_batch(self, query: str, max_results: int, full: bool = False,
                     proxy_config: dict | None = None) -> tuple[list[NssmResult], int, str]:
        # ZoomEye 单次 pagesize 最大有限制，需要分页
        all_results = []
        total = 0
        pages = min((max_results + self.size - 1) // self.size, 10)  # 最多10页
        for page in range(1, pages + 1):
            results, t, err = self.search(query, page, full, proxy_config)
            if err:
                return all_results, total, err
            total = t
            all_results.extend(results)
            if len(all_results) >= max_results:
                break
            time.sleep(0.5)
        return all_results[:max_results], total, ""


# ════════════════════════════════════════
# 0.zone (零零信安) 引擎
# ════════════════════════════════════════
class ZeroZoneClient:
    """0.zone API: POST + zone_key_id 认证 + JSON body
    三种查询类型: site(信息系统), app(移动应用), domain(域名)"""

    BASE_URL = "https://0.zone/api/data/"

    def __init__(self, zone_key_id="", size=100, maxsize=10000):
        self.zone_key_id = zone_key_id
        self.size = size
        self.maxsize = maxsize

    def search(self, query: str, query_type: str = "site", page: int = 1,
               proxy_config: dict | None = None) -> tuple[list[NssmResult], int, str]:
        body = {
            "query": query.replace('"', ''),
            "query_type": query_type,
            "page": page,
            "pagesize": self.size,
            "zone_key_id": self.zone_key_id,
        }
        resp = _http_post(self.BASE_URL, body, proxy_config=proxy_config)
        if not resp:
            return [], 0, "请求失败"
        try:
            obj = json.loads(resp)
        except json.JSONDecodeError:
            return [], 0, f"JSON解析失败"

        if obj.get("code") != 0:
            return [], 0, obj.get("message", "未知错误")

        total = int(obj.get("total", 0))
        results = []
        for item in obj.get("data", []):
            if query_type == "site":
                host = item.get("hostname", "")
                domain = item.get("url", "")
                if not host:
                    host = domain if domain else (
                        f"https://{item.get('ip', '')}" if item.get("port") == 443 else
                        f"http://{item.get('ip', '')}" if item.get("port") == 80 else
                        f"{item.get('ip', '')}:{item.get('port', 0)}"
                    )
                results.append(NssmResult(
                    host=host, title=item.get("title", ""),
                    ip=item.get("ip", ""), domain=domain,
                    port=int(item.get("port", 0)),
                    protocol=item.get("protocol", ""),
                    server=item.get("os", ""),
                    city=item.get("city", ""),
                    icp=item.get("beian", ""),
                ))
            elif query_type == "app":
                results.append(NssmResult(
                    title=item.get("title", ""),
                    icp=item.get("icp", ""),
                    extra={
                        "company": item.get("company", ""),
                        "type": item.get("type", ""),
                        "check_time": item.get("check_time", ""),
                        "msg_app_id": item.get("msg_app_id", ""),
                        "msg_wechat_id": item.get("msg_wechat_id", ""),
                        "msg_introduction": item.get("msg_introduction", ""),
                        "app_url": item.get("app_url", ""),
                        "timestamp": item.get("timestamp", ""),
                    }
                ))
            elif query_type == "domain":
                results.append(NssmResult(
                    domain=item.get("domain", ""),
                    icp=item.get("icp", ""),
                    extra={
                        "company": item.get("company", ""),
                        "toplv_domain": item.get("toplv_domain", ""),
                        "url": item.get("url", ""),
                    }
                ))
        return results, total, ""


# ════════════════════════════════════════
# 工具函数
# ════════════════════════════════════════
_IPV4_PATTERN = re.compile(
    r"^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$"
)


def _is_ip(s: str) -> bool:
    if not s:
        return False
    clean = s.replace("https://", "").replace("http://", "")
    # 用 find 避免 ValueError
    idx = clean.find(":")
    if idx != -1:
        clean = clean[:idx]
    idx = clean.find("/")
    if idx != -1:
        clean = clean[:idx]
    return bool(_IPV4_PATTERN.match(clean))


def format_host_url(host: str, protocol: str = "", port: int = 0) -> str:
    """拼接完整 HOST URL，非标准端口自动追加 :port"""
    if not host:
        return ""
    host = str(host).strip()
    try:
        port = int(port) if port else 0
    except (ValueError, TypeError):
        port = 0
    if not port:
        return host

    # 标准端口不追加
    proto_str = str(protocol).lower()
    if "https" in proto_str or "ssl" in proto_str:
        standard = 443
        scheme = "https"
    else:
        standard = 80
        scheme = "http"
    if port == standard:
        return host

    # 已有该端口则不重复
    if re.search(rf':{port}(?:/|$)', host):
        return host

    # 拆分出 scheme / hostname / path
    has_scheme = host.startswith(("http://", "https://"))
    if not has_scheme:
        host = f"{scheme}://{host}"

    parsed = urlparse(host)
    hostname = parsed.hostname or ""
    # 域名不追加端口（仅 IP 追加）
    if hostname and not _is_ip(hostname):
        return host
    path = parsed.path or ""
    return f"{parsed.scheme}://{hostname}:{port}{path}"


# ════════════════════════════════════════
# 统一查询入口
# ════════════════════════════════════════
ENGINE_TYPES = ["FOFA", "Hunter", "Quake", "ZoomEye", "0.zone-site", "0.zone-app", "0.zone-domain"]


class NssmSearchEngine:
    """统一的网络空间搜索引擎查询器"""

    def __init__(self, config: dict | None = None):
        """
        config:
          fofa: {email, key, size, maxsize}
          hunter: {apikey, size, maxsize}
          quake: {apikey, size, maxsize}
          zoomeye: {apikey, size, maxsize}
          zerokey: {zone_key_id, size, maxsize}
          proxy: {isrun, proxytype, ip, port, username, password}
        """
        cfg = config or {}
        fofa = cfg.get("fofa", {})
        hunter = cfg.get("hunter", {})
        quake = cfg.get("quake", {})
        zoomeye = cfg.get("zoomeye", {})
        zero = cfg.get("zerokey", {})
        self.proxy_config = cfg.get("proxy")

        self.fofa = FofaClient(fofa.get("email", ""), fofa.get("key", ""),
                               fofa.get("size", 50), fofa.get("maxsize", 10000),
                               fofa.get("url", "https://fofa.info"))
        self.hunter = HunterClient(hunter.get("apikey", ""),
                                   hunter.get("size", 50), hunter.get("maxsize", 10000))
        self.quake = QuakeClient(quake.get("apikey", ""),
                                 quake.get("size", 50), quake.get("maxsize", 10000))
        self.zoomeye = ZoomEyeClient(zoomeye.get("apikey", ""),
                                     zoomeye.get("size", 100), zoomeye.get("maxsize", 10000))
        self.zero = ZeroZoneClient(zero.get("zone_key_id", ""),
                                   zero.get("size", 100), zero.get("maxsize", 10000))

    def search(self, engine: str, query: str, page: int = 1, full: bool = False,
               proxy_config: dict | None = None) -> tuple[list[NssmResult], int, str]:
        """
        engine: FOFA | Hunter | Quake | ZoomEye | 0.zone-site | 0.zone-app | 0.zone-domain
        full: True=搜索全部时间  False=仅近一年
        返回: (结果列表, 总数, 错误信息)
        """
        px = proxy_config or self.proxy_config
        if engine == "FOFA":
            return self.fofa.search(query, page, full, px)
        elif engine == "Hunter":
            return self.hunter.search(query, page, full, px)
        elif engine == "Quake":
            return self.quake.search(query, page, full, px)
        elif engine == "ZoomEye":
            return self.zoomeye.search(query, page, full, px)
        elif engine == "0.zone-site":
            return self.zero.search(query, "site", page, px)
        elif engine == "0.zone-app":
            return self.zero.search(query, "app", page, px)
        elif engine == "0.zone-domain":
            return self.zero.search(query, "domain", page, px)
        else:
            return [], 0, f"不支持的引擎: {engine}"

    def search_batch(self, engine: str, query: str, max_results: int,
                     full: bool = False,
                     proxy_config: dict | None = None) -> tuple[list[NssmResult], int, str]:
        """批量查询，一次拿 max_results 条"""
        px = proxy_config or self.proxy_config
        if engine == "FOFA":
            return self.fofa.search_batch(query, max_results, full, px)
        elif engine == "Hunter":
            return self.hunter.search_batch(query, max_results, full, px)
        elif engine == "Quake":
            return self.quake.search_batch(query, max_results, full, px)
        elif engine == "ZoomEye":
            return self.zoomeye.search_batch(query, max_results, full, px)
        else:
            # 0.zone 不支持 batch，回退到普通搜索
            return self.search(engine, query, 1, full, px)

    def search_multi(self, engine: str, queries: list[str], max_per_query: int,
                     full: bool = False,
                     progress_callback=None,
                     proxy_config: dict | None = None) -> list[NssmResult]:
        """
        批量关键词查询（复刻 NSSMMultiTask）
        每个关键词查 max_per_query 条，聚合所有结果
        """
        all_results = []
        for i, q in enumerate(queries):
            q = q.strip()
            if not q:
                continue
            results, _, _ = self.search_batch(engine, q, max_per_query, full, proxy_config)
            all_results.extend(results)
            if progress_callback:
                progress_callback(i + 1, len(queries), q, len(results))
            # 请求间隔（原版 FOFA 500ms, Hunter 2000ms, Quake 1500ms）
            if i < len(queries) - 1:
                if engine == "Hunter":
                    time.sleep(2)
                elif engine == "Quake":
                    time.sleep(1.5)
                else:
                    time.sleep(0.5)
        return all_results


# ════════════════════════════════════════
# Icon Hash 计算（复刻 HttpIconHelper）
# ════════════════════════════════════════
def calc_icon_hash(data: bytes) -> dict:
    """
    计算 favicon 的多种 hash，完全复刻原版 HttpIconHelper
    FOFA:  Base64-MIME 编码 icon bytes → 去 \\r 加 \\n → MurmurHash3_32 → 数字字符串
    Quake / Hunter / ZoomEye: 原始 icon bytes 的 MD5 hex
    """
    md5_hex = hashlib.md5(data).hexdigest()

    # FOFA 官方算法: MIME Base64(每76字符换行) -> MurmurHash3_32 -> signed int32
    b64_str = base64.encodebytes(data).decode()
    if mmh3 is None:
        raise ImportError("mmh3 模块未安装，无法计算 FOFA icon_hash")
    fofa_val = mmh3.hash(b64_str)

    return {
        "fofa": f"icon_hash=\"{fofa_val}\"",
        "quake": f"favicon:\"{md5_hex}\"",
        "hunter": f"web.icon=\"{md5_hex}\"",
    }




def _is_image(resp, data: bytes) -> bool:
    """检查 HTTP 响应是否为有效图片（防302重定向到HTML被抓成icon）"""
    ct = resp.headers.get("Content-Type", "")
    if "image/" not in ct:
        return False
    # ICO 文件最小约 318 bytes，宽限到 64
    return len(data) >= 64


def fetch_icon_hash_from_url(url: str) -> dict | None:
    """从 URL 下载 favicon 并计算 hash（支持自动发现 favicon）"""
    try:
        # 如果 URL 不是直接指向 icon 文件，尝试智能获取
        if not url.lower().endswith(('.ico', '.png', '.jpg', '.jpeg', '.svg', '.gif')):
            return _smart_fetch_icon(url)

        req = Request(url)
        req.add_header("User-Agent", _random_ua())
        req.add_header("Accept-Encoding", "identity")
        req.add_header("Accept", "image/*,*/*")
        with urlopen(req, timeout=20, context=_SSL_CONTEXT) as resp:
            data = resp.read()
        if not _is_image(resp, data):
            _logger.warning("[icon] 非图片响应 (Content-Type=%s), 尝试智能获取...", resp.headers.get('Content-Type', '?'))
            return _smart_fetch_icon(url)
        _logger.info("[icon] 下载 %d bytes", len(data))
        return calc_icon_hash(data)
    except Exception as e:
        _logger.error("获取 icon 失败: %s", e)
        return _smart_fetch_icon(url)


def _smart_fetch_icon(url: str) -> dict | None:
    """智能获取 favicon：先取网页 HTML，解析 favicon 链接再下载"""
    try:
        # 确保 URL 有协议
        if not url.startswith('http'):
            url = 'https://' + url

        # 先尝试标准路径
        for icon_path in ['/favicon.ico', '/favicon.png']:
            parsed = urlparse(url if url.startswith('http') else 'https://' + url)
            icon_url = f"{parsed.scheme}://{parsed.netloc}{icon_path}"
            try:
                req = Request(icon_url)
                req.add_header("User-Agent", _random_ua())
                req.add_header("Accept-Encoding", "identity")
                with urlopen(req, timeout=20, context=_SSL_CONTEXT) as resp:
                    data = resp.read()
                if _is_image(resp, data):
                    _logger.info("[icon] 智能获取: %s (%d bytes)", icon_url, len(data))
                    return calc_icon_hash(data)
            except Exception:
                pass

        # 再尝试从 HTML 解析 <link rel="icon">
        req = Request(url)
        req.add_header("User-Agent", _random_ua())
        req.add_header("Accept", "text/html")
        with urlopen(req, timeout=20, context=_SSL_CONTEXT) as resp:
            html = resp.read().decode('utf-8', errors='ignore')

        # 匹配 <link rel="icon" href="..."> / <link rel="shortcut icon" href="...">
        patterns = [
            r'<link[^>]*rel=["\'](?:shortcut\s+)?icon["\'][^>]*href=["\']([^"\']+)',
            r'<link[^>]*href=["\']([^"\']+)["\'][^>]*rel=["\'](?:shortcut\s+)?icon["\']',
        ]
        for pat in patterns:
            m = re.search(pat, html, re.IGNORECASE)
            if m:
                href = m.group(1)
                icon_url = urljoin(url, href)
                try:
                    req = Request(icon_url)
                    req.add_header("User-Agent", _random_ua())
                    req.add_header("Accept-Encoding", "identity")
                    with urlopen(req, timeout=20, context=_SSL_CONTEXT) as resp:
                        data = resp.read()
                    if _is_image(resp, data):
                        _logger.info("[icon] HTML解析获取: %s (%d bytes)", icon_url, len(data))
                        return calc_icon_hash(data)
                except Exception:
                    pass

        _logger.warning("无法从 %s 找到 favicon", url)
        return None
    except Exception as e:
        _logger.error("智能获取 icon 失败: %s", e)
        return None


def fetch_icon_hash_from_file(filepath: str) -> dict | None:
    """从本地文件读取 icon 并计算 hash"""
    try:
        with open(filepath, "rb") as f:
            data = f.read()
        return calc_icon_hash(data)
    except Exception as e:
        _logger.error("读取 icon 文件失败: %s", e)
        return None


# ════════════════════════════════════════
# 查询语法速查表（取自 nssmconfig.json）
# ════════════════════════════════════════
NSSM_CONFIG = [
    {"name": "IP", "fofa": 'ip="192.168.0.1"', "hunter": 'ip="192.168.0.1"',
     "quake": 'ip:"192.168.0.1"', "zoomeye": 'ip:"192.168.0.1"', "zero": "ip==192.168.0.1"},
    {"name": "C段", "fofa": 'ip="192.168.0.1/24"', "hunter": 'ip="192.168.0.1/24"',
     "quake": 'ip:"192.168.0.1/24"', "zoomeye": 'ip:"192.168.0.1/24"', "zero": "<不支持>"},
    {"name": "域名", "fofa": 'domain="google.com"', "hunter": 'domain="google.com"',
     "quake": 'domain:"google.com"', "zoomeye": 'domain:"google.com"', "zero": "domain==google.com"},
    {"name": "HOST", "fofa": 'host="google.com"', "hunter": 'host="google.com"',
     "quake": 'host:"google.com"', "zoomeye": 'host:"google.com"', "zero": "host==google.com"},
    {"name": "端口", "fofa": 'port="80"', "hunter": 'ip.port="80"',
     "quake": 'port:"80"', "zoomeye": 'port:"80"', "zero": "port==80"},
    {"name": "title", "fofa": 'title="标题"', "hunter": 'web.title="标题"',
     "quake": 'response:"标题"', "zoomeye": 'title:"标题"', "zero": "title==标题"},
    {"name": "body", "fofa": 'body="内容"', "hunter": 'web.body="内容"',
     "quake": 'response:"内容"', "zoomeye": 'body:"内容"', "zero": "body==内容"},
    {"name": "OS", "fofa": 'os="centos"', "hunter": 'os="centos"',
     "quake": 'os:"centos"', "zoomeye": 'os:"centos"', "zero": "os==Centos"},
    {"name": "app", "fofa": 'app="Nginx"', "hunter": 'app.name="Nginx"',
     "quake": 'app:"Nginx"', "zoomeye": 'app:"Nginx"', "zero": "component==Nginx"},
    {"name": "country", "fofa": 'country="中国"', "hunter": 'ip.country="中国"',
     "quake": 'country_cn:"中国"', "zoomeye": 'country.name="CN"', "zero": "country=CN"},
    {"name": "Region", "fofa": 'region="山东"', "hunter": 'ip.province="山东"',
     "quake": 'province:"山东"', "zoomeye": 'province.name="山东"', "zero": "province=山东"},
    {"name": "city", "fofa": 'city="北京"', "hunter": 'ip.city="北京"',
     "quake": 'city:"北京"', "zoomeye": 'city:"北京"', "zero": "city=北京"},
    {"name": "ICP", "fofa": 'icp="备案号"', "hunter": 'icp.number="备案号"',
     "quake": 'icp:"备案号"', "zoomeye": "<不支持>", "zero": "icp==备案号"},
    {"name": "protocol", "fofa": 'protocol="http"', "hunter": 'protocol="http"',
     "quake": 'service:"ssh"', "zoomeye": 'service:"ssh"', "zero": "service==http"},
    {"name": "Icon", "fofa": 'icon_hash="mmh3"', "hunter": 'web.icon="MD5"',
     "quake": 'favicon:"MD5"', "zoomeye": 'iconhash="MD5"', "zero": "icon=MD5"},
    {"name": "isp", "fofa": 'isp="电信"', "hunter": 'isp.name="电信"',
     "quake": 'service.provider:"China Education and Research Network"',
     "zoomeye": 'isp:"电信"', "zero": "isp==电信"},
    {"name": "header", "fofa": 'header="elastic"', "hunter": 'header="elastic"',
     "quake": 'headers:"ThinkPHP"', "zoomeye": 'http.header:"http"', "zero": "res_header==nginx"},
    {"name": "cert", "fofa": 'cert="baidu"', "hunter": 'cert="baidu"',
     "quake": 'cert:"360.cn"', "zoomeye": 'ssl.cert.fingerprint="..."', "zero": "<不支持>"},
    {"name": "server", "fofa": 'server="IIS"', "hunter": 'header.server=="IIS"',
     "quake": "server:Nginx", "zoomeye": 'http.header.server="Nginx"', "zero": "<不支持>"},
    {"name": "banner", "fofa": 'banner="users"', "hunter": 'protocol.banner="nginx"',
     "quake": "<不支持>", "zoomeye": 'banner:"FTP"', "zero": "banner==零零信安"},
    {"name": "status_code", "fofa": 'status_code="200"', "hunter": 'header.status_code="200"',
     "quake": "status_code:200", "zoomeye": 'http.header.status_code="200"', "zero": "status_code=200"},
]


if __name__ == "__main__":
    print("网络空间搜索引擎查询模块已加载")
    print(f"支持引擎: {ENGINE_TYPES}")
