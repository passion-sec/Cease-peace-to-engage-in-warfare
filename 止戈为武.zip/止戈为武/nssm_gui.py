"""
止戈为武 - PassionSec - GUI 界面
统一标签栏设计：所有功能点 + 查询结果在同一标签栏切换，查询栏共享
"""
import base64
import json
import os
import re
import shlex
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime
from urllib.parse import urlparse

from nssm_engine import (
    NssmSearchEngine, ENGINE_TYPES, NSSM_CONFIG,
    fetch_icon_hash_from_url, fetch_icon_hash_from_file,
    format_host_url
)
from icp_query import IcpQueryEngine, QUERY_TYPE_MAP, BLACK_TYPE_MAP

try:
    import paramiko
except ImportError:
    paramiko = None

try:
    import openpyxl
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Font, Alignment, Border, Side, PatternFill
    from openpyxl.cell.text import InlineFont
    from openpyxl.cell.rich_text import TextBlock, CellRichText
    from openpyxl.utils import get_column_letter
except ImportError:
    openpyxl = None
    Workbook = None
    load_workbook = None
    get_column_letter = None

CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")


def load_config() -> dict:
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_config(cfg: dict):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


COLUMNS = ("#", "HOST/URL", "标题", "IP", "域名", "端口", "协议", "服务指纹", "城市", "ICP备案")
COL_WIDTHS = [40, 220, 180, 120, 120, 55, 65, 100, 70, 120]
COL_MAP = {"#": 0, "HOST/URL": 1, "标题": 2, "IP": 3, "域名": 4,
           "端口": 5, "协议": 6, "服务指纹": 7, "城市": 8, "ICP备案": 9}

# 功能标签名称常量（不可关闭的标签）
FUNC_TAB_NAMES = {
    "查询结果", "批量查询", "Icon哈希", "备忘录语法",
    "端口扫描", "暴力扫描", "去重合并", "查询结果导出", "工具配置", "ICP查询"
}


# ════════════════════════════════════════
# 单个查询结果 Tab
# ════════════════════════════════════════
class SearchTab:
    """封装一个查询 Tab 的所有状态和 UI"""

    def __init__(self, parent_notebook, engine_type, query, engine, page_size, default_pages, full):
        self.notebook = parent_notebook
        self.engine_type = engine_type
        self.query = query
        self.engine = engine
        self.page_size = page_size
        self.default_pages = default_pages
        self.full = full

        self.results = []
        self.total = 0
        self.max_page = 1
        self.loaded_pages = set()
        self.is_loading = False
        self.sort_col = None
        self.sort_reverse = False

        self.frame = ttk.Frame(parent_notebook)
        self._build_ui()

    def _build_ui(self):
        self.tree = ttk.Treeview(self.frame, columns=COLUMNS, show="headings", selectmode="extended")
        for col, w in zip(COLUMNS, COL_WIDTHS):
            self.tree.heading(col, text=col, command=lambda c=col: self._sort_by(c))
            self.tree.column(col, width=w, minwidth=30)

        vsb = ttk.Scrollbar(self.frame, orient=tk.VERTICAL, command=self.tree.yview)
        hsb = ttk.Scrollbar(self.frame, orient=tk.HORIZONTAL, command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        self.frame.rowconfigure(0, weight=1)
        self.frame.columnconfigure(0, weight=1)

        self.tree.tag_configure("even", background="#ffffff")
        self.tree.tag_configure("odd", background="#f2f2f2")

        self.menu = tk.Menu(self.frame, tearoff=0)
        self.menu.add_command(label="复制HOST", command=lambda: self._copy_cell("host"))
        self.menu.add_command(label="复制IP", command=lambda: self._copy_cell("ip"))
        self.menu.add_separator()
        self.menu.add_command(label="全选", command=lambda: self.tree.selection_set(self.tree.get_children()))
        self.tree.bind("<Button-3>", self._show_menu)
        self.tree.bind("<Double-1>", lambda e: self._copy_cell())

        bottom = ttk.Frame(self.frame, padding="3")
        bottom.grid(row=2, column=0, columnspan=2, sticky="ew")

        self.status_label = ttk.Label(bottom, text="", foreground="gray")
        self.status_label.pack(side=tk.LEFT)

        page_frame = ttk.Frame(bottom)
        page_frame.pack(side=tk.RIGHT)
        self.page_label = ttk.Label(page_frame, text="已加载 0 / 0 条")
        self.page_label.pack(side=tk.LEFT, padx=5)
        self.load_more_btn = ttk.Button(page_frame, text="加载更多", command=self._load_more, width=8)
        self.load_more_btn.pack(side=tk.LEFT, padx=2)
        self.load_more_btn.configure(state="disabled")

        self.progress = ttk.Progressbar(bottom, mode="indeterminate", length=100)

    def start_search(self, page=1):
        if self.is_loading:
            return
        self.is_loading = True
        self.progress.pack(side=tk.LEFT, padx=10)
        self.progress.start()
        self.status_label.configure(text="正在查询...", foreground="blue")

        def _run():
            results, total, err = self.engine.search(self.engine_type, self.query, page, self.full)
            self.frame.after(0, lambda: self._on_first_page(results, total, err, page))

        threading.Thread(target=_run, daemon=True).start()

    def _on_first_page(self, results, total, err, page):
        self.is_loading = False
        self.progress.stop()
        self.progress.pack_forget()

        if err:
            self.status_label.configure(text=f"查询失败: {err}", foreground="red")
            messagebox.showerror("查询失败", err)
            return

        self.results = results
        self.total = total
        self.max_page = max(1, (total + self.page_size - 1) // self.page_size)
        self.loaded_pages = {page}
        self._refresh_table()
        self._update_load_state()
        self.status_label.configure(
            text=f"已加载 {len(results)} 条 / 共 {total} 条", foreground="green")
        self._auto_load_more()

    def _auto_load_more(self):
        next_page = self._next_unloaded()
        if next_page is None:
            return
        loaded_count = len(self.loaded_pages)
        if loaded_count >= self.default_pages:
            return
        self.frame.after(500, lambda: self._load_page(next_page))

    def _load_page(self, page):
        if self.is_loading:
            return
        if page in self.loaded_pages:
            return
        self.is_loading = True
        self.progress.pack(side=tk.LEFT, padx=10)
        self.progress.start()
        self.status_label.configure(text=f"正在加载第 {page} 页...", foreground="blue")

        def _run():
            results, total, err = self.engine.search(self.engine_type, self.query, page, self.full)
            self.frame.after(0, lambda: self._on_page_loaded(results, total, err, page))

        threading.Thread(target=_run, daemon=True).start()

    def _on_page_loaded(self, results, total, err, page):
        self.is_loading = False
        self.progress.stop()
        self.progress.pack_forget()
        if err:
            self.status_label.configure(text=f"加载失败: {err}", foreground="red")
            return
        self.results.extend(results)
        self.total = total
        self.max_page = max(1, (total + self.page_size - 1) // self.page_size)
        self.loaded_pages.add(page)
        self._refresh_table()
        self._update_load_state()
        self.status_label.configure(
            text=f"已加载 {len(self.results)} 条 / 共 {total} 条", foreground="green")
        self._auto_load_more()

    def _next_unloaded(self):
        for p in range(1, self.max_page + 1):
            if p not in self.loaded_pages:
                return p
        return None

    def _load_more(self):
        next_page = self._next_unloaded()
        if next_page is not None:
            self._load_page(next_page)

    def _refresh_table(self):
        self.tree.delete(*self.tree.get_children())
        for i, r in enumerate(self.results):
            tag = "even" if i % 2 == 0 else "odd"
            host = format_host_url(r.host, r.protocol, r.port)
            self.tree.insert("", tk.END, iid=str(i), values=(
                i + 1, host, r.title, r.ip, r.domain, r.port,
                r.protocol, r.server, r.city, r.icp
            ), tags=(tag,))

    def _update_load_state(self):
        self.page_label.configure(text=f"已加载 {len(self.results)} / {self.total} 条")
        has_more = self._next_unloaded() is not None
        self.load_more_btn.configure(state="normal" if has_more else "disabled")

    def _sort_by(self, col_name):
        idx = COL_MAP.get(col_name, 0)
        if self.sort_col == idx:
            self.sort_reverse = not self.sort_reverse
        else:
            self.sort_col = idx
            self.sort_reverse = False
        self.results.sort(key=lambda r: str(r.to_row()[idx]), reverse=self.sort_reverse)
        self._refresh_table()

    def _show_menu(self, event):
        try:
            self.tree.selection_set(self.tree.identify_row(event.y))
        except Exception:
            pass
        self.menu.post(event.x_root, event.y_root)

    def _copy_cell(self, field="host"):
        sel = self.tree.selection()
        if not sel:
            return
        col_idx = 1 if field == "host" else 3
        item = self.tree.item(sel[0])
        val = item["values"][col_idx] if len(item["values"]) > col_idx else ""
        self.frame.clipboard_clear()
        self.frame.clipboard_append(str(val))

    def get_tab_title(self):
        short = self.query[:16] + ".." if len(self.query) > 16 else self.query
        return f"[{self.engine_type}] {short}"

    def check_keywords_match(self, new_query):
        return new_query.startswith(self.query) or self.query.startswith(new_query)


# ════════════════════════════════════════
# 主窗口
# ════════════════════════════════════════
class NssmToolGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("止戈为武 - PassionSec")
        self.root.geometry("1300x820")
        self.root.minsize(1000, 600)

        self._setup_style()

        self.config = load_config()
        self.engine = NssmSearchEngine(self.config)
        self.tabs = {}
        self._batch_running = 0
        self._batch_lock = threading.Lock()
        self.query_history = []

        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _setup_style(self):
        style = ttk.Style()
        default_font = ("", 10)
        style.configure(".", font=default_font)
        style.configure("TLabel", font=default_font)
        style.configure("TButton", font=default_font, padding=(8, 3))
        style.configure("TCheckbutton", font=default_font)
        style.configure("TCombobox", font=default_font)
        style.configure("TEntry", font=default_font, padding=(4, 3))
        style.configure("Treeview", font=default_font, rowheight=24)

    # ════════════════════════════════════
    # UI 构建
    # ════════════════════════════════════
    def _build_ui(self):
        # ── 顶部共享查询栏 ──
        query_bar = ttk.Frame(self.root, padding="6")
        query_bar.pack(fill=tk.X)

        # 第一行: 引擎 + 查询输入 + 查询按钮
        row1 = ttk.Frame(query_bar)
        row1.pack(fill=tk.X)
        ttk.Label(row1, text="引擎:").pack(side=tk.LEFT)
        self.engine_var = tk.StringVar(value="FOFA")
        self.engine_combo = ttk.Combobox(row1, textvariable=self.engine_var,
                                         values=ENGINE_TYPES, state="readonly", width=14)
        self.engine_combo.pack(side=tk.LEFT, padx=(6, 12))
        ttk.Label(row1, text="查询语法:").pack(side=tk.LEFT)
        self.query_entry = ttk.Entry(row1, width=60)
        self.query_entry.pack(side=tk.LEFT, padx=6, fill=tk.X, expand=True)
        self.query_entry.bind("<Return>", lambda e: self._start_search())

        self.multi_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(row1, text="多引擎", variable=self.multi_var).pack(side=tk.LEFT, padx=3)
        self.search_btn = ttk.Button(row1, text="查询", command=self._start_search, width=6)
        self.search_btn.pack(side=tk.LEFT, padx=6)

        # 第二行: 查询参数设置
        row2 = ttk.Frame(query_bar)
        row2.pack(fill=tk.X, pady=(4, 0))
        ttk.Label(row2, text="每页:").pack(side=tk.LEFT)
        self.page_size_var = tk.StringVar(value="500")
        ttk.Entry(row2, textvariable=self.page_size_var, width=6).pack(side=tk.LEFT, padx=4)
        ttk.Label(row2, text="最大页:").pack(side=tk.LEFT, padx=(8, 0))
        self.max_page_var = tk.StringVar(value="3")
        ttk.Entry(row2, textvariable=self.max_page_var, width=6).pack(side=tk.LEFT, padx=4)
        self.full_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(row2, text="全部时间", variable=self.full_var).pack(side=tk.LEFT, padx=12)

        # ── 功能标签按钮栏 ──
        self._func_tab_names = [
            "查询结果", "ICP查询", "批量查询", "Icon哈希",
            "端口扫描", "暴力扫描", "去重合并", "查询结果导出",
            "备忘录语法", "工具配置"
        ]
        tab_bar = ttk.Frame(self.root)
        tab_bar.pack(fill=tk.X, padx=5, pady=(3, 0))

        self._func_btns = {}
        for i, name in enumerate(self._func_tab_names):
            btn = ttk.Button(tab_bar, text=name,
                             command=lambda n=name: self._switch_func_tab(n))
            btn.pack(side=tk.LEFT, padx=(0, 2), pady=1)
            self._func_btns[name] = btn

        # 分割线（双线）
        ttk.Separator(self.root, orient=tk.HORIZONTAL).pack(fill=tk.X, padx=5, pady=(0, 0))
        ttk.Separator(self.root, orient=tk.HORIZONTAL).pack(fill=tk.X, padx=5, pady=(1, 0))

        # ── 功能内容区 ──
        self._content_frame = ttk.Frame(self.root)
        self._content_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=2)

        # 创建所有功能面板（全部放在 content_frame 中，初始隐藏）
        self._function_frames = {}
        self._create_base_query_panel()   # 查询结果（含语法速查 + 查询结果子标签）
        self._create_batch_panel()         # 批量查询
        self._create_icon_panel()          # Icon哈希
        self._create_syntax_panel()        # 备忘录语法
        self._create_portscan_panel()      # 端口扫描
        self._create_brutescan_panel()     # 暴力扫描
        self._create_dedup_panel()         # 去重合并
        self._create_export_panel()        # 查询结果导出
        self._create_config_panel()        # 工具配置
        self._create_icp_panel()          # ICP查询

        # 默认显示查询结果
        self._switch_func_tab("查询结果")

        # ── 底部状态栏 ──
        self.global_status = ttk.Label(self.root, text="", foreground="gray", padding="3")
        self.global_status.pack(fill=tk.X)

    # ════════════════════════════════════
    # 功能面板: 查询结果（含语法速查 + 查询结果子标签）
    # ════════════════════════════════════
    def _create_base_query_panel(self):
        frame = ttk.Frame(self._content_frame)
        self._function_frames["查询结果"] = frame

        # 内部子标签栏: 语法速查 + 动态查询结果
        self._result_notebook = ttk.Notebook(frame)
        self._result_notebook.pack(fill=tk.BOTH, expand=True)

        # 子标签右键菜单（关闭查询结果）
        self._sub_tab_menu = tk.Menu(frame, tearoff=0)
        self._sub_tab_menu.add_command(label="关闭", command=self._close_selected_subtab)
        self._sub_tab_menu.add_command(label="关闭其他", command=self._close_other_subtabs)
        self._sub_tab_menu.add_command(label="关闭所有结果", command=self._close_all_subtabs)
        self._result_notebook.bind("<Button-3>", self._show_sub_tab_menu)

        # ── 语法速查子标签（永久）──
        syntax_frame = ttk.Frame(self._result_notebook, padding="5")
        self._result_notebook.add(syntax_frame, text="语法速查")

        ttk.Label(syntax_frame, text="查询语法速查表（双击 → 添加到查询框）",
                  font=("", 10, "bold")).pack(anchor=tk.W, pady=(0, 5))

        columns = ("语法名称", "FOFA", "Hunter", "Quake", "ZoomEye", "零零信安")
        tree = ttk.Treeview(syntax_frame, columns=columns, show="headings")
        for col in columns:
            tree.heading(col, text=col)
        tree.column("语法名称", width=80)
        tree.column("FOFA", width=280)
        tree.column("Hunter", width=280)
        tree.column("Quake", width=220)
        tree.column("ZoomEye", width=220)
        tree.column("零零信安", width=180)

        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb = ttk.Scrollbar(syntax_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)

        tree.tag_configure("even", background="#ffffff")
        tree.tag_configure("odd", background="#f2f2f2")

        for i, row in enumerate(NSSM_CONFIG):
            tag = "even" if i % 2 == 0 else "odd"
            tree.insert("", tk.END, values=(
                row["name"], row["fofa"], row["hunter"],
                row["quake"], row["zoomeye"], row["zero"]
            ), tags=(tag,))

        def on_double_click(event):
            sel = tree.selection()
            if not sel:
                return
            item = tree.item(sel[0])
            vals = item["values"]
            engine = self.engine_var.get()
            col_idx = {"FOFA": 1, "Hunter": 2, "Quake": 3, "ZoomEye": 4,
                       "0.zone-site": 5, "0.zone-app": 5, "0.zone-domain": 5}.get(engine, 1)
            syntax = vals[col_idx] if len(vals) > col_idx else vals[1]
            current = self.query_entry.get()
            if current:
                self.query_entry.insert(tk.END, " && " + syntax)
            else:
                self.query_entry.insert(0, syntax)

        tree.bind("<Double-1>", on_double_click)

        # 右键菜单: 添加到查询框
        syntax_menu = tk.Menu(syntax_frame, tearoff=0)

        def _add_to_query():
            sel = tree.selection()
            if not sel:
                return
            item = tree.item(sel[0])
            vals = item["values"]
            engine = self.engine_var.get()
            col_idx = {"FOFA": 1, "Hunter": 2, "Quake": 3, "ZoomEye": 4,
                       "0.zone-site": 5, "0.zone-app": 5, "0.zone-domain": 5}.get(engine, 1)
            syntax = vals[col_idx] if len(vals) > col_idx else vals[1]
            current = self.query_entry.get()
            if current:
                self.query_entry.insert(tk.END, " && " + syntax)
            else:
                self.query_entry.insert(0, syntax)

        syntax_menu.add_command(label="添加到查询框", command=_add_to_query)

        def _show_syntax_menu(event):
            try:
                tree.selection_set(tree.identify_row(event.y))
            except Exception:
                pass
            syntax_menu.post(event.x_root, event.y_root)

        tree.bind("<Button-3>", _show_syntax_menu)

    # ════════════════════════════════════
    # 功能面板: 批量查询
    # ════════════════════════════════════
    def _create_batch_panel(self):
        frame = ttk.Frame(self._content_frame)
        self._function_frames["批量查询"] = frame

        top = ttk.Frame(frame)
        top.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # 顶部: 引擎选择
        engine_row = ttk.Frame(top)
        engine_row.pack(fill=tk.X, pady=(0, 5))
        ttk.Label(engine_row, text="批量查询引擎:").pack(side=tk.LEFT)
        self._batch_engine_var = tk.StringVar(value="FOFA")
        batch_engine_combo = ttk.Combobox(engine_row, textvariable=self._batch_engine_var,
                                          values=("FOFA", "Hunter", "Quake"),
                                          state="readonly", width=12)
        batch_engine_combo.pack(side=tk.LEFT, padx=6)

        batch_multi_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(engine_row, text="多引擎", variable=batch_multi_var).pack(side=tk.LEFT, padx=10)

        batch_full_var = tk.BooleanVar(value=self.full_var.get())
        ttk.Checkbutton(engine_row, text="全部时间", variable=batch_full_var).pack(side=tk.RIGHT, padx=5)

        # 左: 查询语法
        left = ttk.Frame(top)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 3))
        ttk.Label(left, text="查询语法 ({domain}/{name}/{title}/{body}/{icp}=占位符):", padding=2).pack(anchor=tk.W)
        text_area = tk.Text(left, height=14, font=("Consolas", 10), width=42)
        text_area.pack(fill=tk.BOTH, expand=True)

        batch_cfg = self.config.get("batch_history", {})

        def _load_batch_engine(eng):
            """切换引擎时加载对应的查询语法"""
            text_area.delete("1.0", tk.END)
            hist_q = batch_cfg.get(f"{eng}_query", "")
            if hist_q:
                text_area.insert("1.0", hist_q)

        def _on_batch_engine_changed(*args):
            eng = batch_engine_combo.get()
            _load_batch_engine(eng)

        batch_engine_combo.bind("<<ComboboxSelected>>", _on_batch_engine_changed)

        # 初始加载当前引擎的配置
        engine0 = batch_engine_combo.get()
        _load_batch_engine(engine0)

        # 右: 五列占位符值
        right = ttk.Frame(top)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, padx=(3, 0))
        placeholder_areas = {}
        for i, (label, var_name, w) in enumerate([
            ("主域名 {domain}", "domain", 14),
            ("单位名称 {name}", "name", 13),
            ("关键词 {title}", "title", 13),
            ("内容 {body}", "body", 14),
            ("备案号 {icp}", "icp", 18),
        ]):
            col = ttk.Frame(right)
            col.pack(side=tk.LEFT, fill=tk.BOTH, padx=(0 if i == 4 else 2, 0))
            ttk.Label(col, text=label, padding=2).pack(anchor=tk.W)
            ta = tk.Text(col, height=14, font=("Consolas", 10), width=w)
            ta.pack(fill=tk.BOTH, expand=True)
            hist_val = batch_cfg.get(var_name, "")
            if hist_val:
                ta.insert("1.0", hist_val)
            placeholder_areas[var_name] = ta

        # 下半部分
        bottom = ttk.Frame(frame)
        bottom.pack(fill=tk.X, padx=5)

        ttk.Label(bottom, text="将生成: 查询语法数 x 域名数 次请求，每条语法拉满全量结果",
                  foreground="gray").pack(side=tk.LEFT)

        def _save_batch():
            cfg = load_config()
            eng = batch_engine_combo.get()
            cfg.setdefault("batch_history", {})[f"{eng}_query"] = text_area.get("1.0", tk.END)
            for vn in ("domain", "name", "title", "body", "icp"):
                cfg["batch_history"][vn] = placeholder_areas[vn].get("1.0", tk.END)
            save_config(cfg)
            self.config = cfg

        def _generate_queries(engine_name, domains, names, titles, bodies, icps):
            batch_cfg2 = self.config.get("batch_history", {})
            queries_raw = [l.strip() for l in batch_cfg2.get(f"{engine_name}_query", "").split("\n") if l.strip()]
            if not queries_raw:
                return []
            max_rows = max(len(domains), len(names), len(titles), len(bodies), len(icps))
            domains = domains + [""] * (max_rows - len(domains))
            names = names + [""] * (max_rows - len(names))
            titles = titles + [""] * (max_rows - len(titles))
            bodies = bodies + [""] * (max_rows - len(bodies))
            icps = icps + [""] * (max_rows - len(icps))
            queries = []
            for row_idx in range(max_rows):
                d, n, t, b, ic = domains[row_idx], names[row_idx], titles[row_idx], bodies[row_idx], icps[row_idx]
                label = d or n or t or b or ic or f"行{row_idx+1}"
                for q in queries_raw:
                    actual = q
                    if d: actual = actual.replace("{domain}", d)
                    if n: actual = actual.replace("{name}", n)
                    if t: actual = actual.replace("{title}", t)
                    if b: actual = actual.replace("{body}", b)
                    if ic: actual = actual.replace("{icp}", ic)
                    if any(p in actual for p in ("{domain}", "{name}", "{title}", "{body}", "{icp}")):
                        continue
                    queries.append((label, actual))
            return queries

        def _run_batch():
            queries_raw = [l.strip() for l in text_area.get("1.0", tk.END).split("\n") if l.strip()]
            domains = [d.strip() for d in placeholder_areas["domain"].get("1.0", tk.END).split("\n") if d.strip()]
            names = [n.strip() for n in placeholder_areas["name"].get("1.0", tk.END).split("\n") if n.strip()]
            titles = [t.strip() for t in placeholder_areas["title"].get("1.0", tk.END).split("\n") if t.strip()]
            bodies = [b.strip() for b in placeholder_areas["body"].get("1.0", tk.END).split("\n") if b.strip()]
            icps = [ic.strip() for ic in placeholder_areas["icp"].get("1.0", tk.END).split("\n") if ic.strip()]

            if not queries_raw:
                messagebox.showwarning("提示", "请输入查询语法")
                return
            if not domains:
                messagebox.showwarning("提示", "请至少输入主域名")
                return

            _save_batch()
            max_per = 10000
            engine = batch_engine_combo.get()
            batch_full = batch_full_var.get()

            if batch_multi_var.get():
                for eng in ("FOFA", "Quake"):
                    queries = _generate_queries(eng, domains, names, titles, bodies, icps)
                    if queries:
                        self._do_batch_search(eng, queries, max_per, batch_full)
            else:
                queries = _generate_queries(engine, domains, names, titles, bodies, icps)
                if queries:
                    self._do_batch_search(engine, queries, max_per, batch_full)

        btn_frame = ttk.Frame(frame, padding=5)
        btn_frame.pack(fill=tk.X)
        ttk.Button(btn_frame, text="开始批量查询", command=_run_batch).pack(side=tk.RIGHT, padx=5)
        ttk.Button(btn_frame, text="保存配置", command=lambda: (_save_batch(), messagebox.showinfo("提示", "配置已保存"))).pack(side=tk.RIGHT, padx=5)

    # ════════════════════════════════════
    # 功能面板: Icon哈希
    # ════════════════════════════════════
    def _create_icon_panel(self):
        frame = ttk.Frame(self._content_frame, padding="10")
        self._function_frames["Icon哈希"] = frame

        ttk.Label(frame, text="Favicon Hash 计算", font=("", 11, "bold")).pack(anchor=tk.W, pady=(0, 10))

        ttk.Label(frame, text="Favicon URL:").pack(anchor=tk.W)
        url_row = ttk.Frame(frame)
        url_row.pack(fill=tk.X, pady=3)
        url_var = tk.StringVar()
        ttk.Entry(url_row, textvariable=url_var, width=50).pack(side=tk.LEFT, fill=tk.X, expand=True)

        result_widgets = {}

        def _do_calc_url():
            url = url_var.get()
            if not url:
                messagebox.showwarning("提示", "请输入URL")
                return

            def _run():
                r = fetch_icon_hash_from_url(url)
                self.root.after(0, lambda: _on_result(r))

            threading.Thread(target=_run, daemon=True).start()

        ttk.Button(url_row, text="获取Hash", command=_do_calc_url).pack(side=tk.LEFT, padx=5)

        ttk.Label(frame, text="或选择本地 .ico 文件:").pack(anchor=tk.W, pady=(15, 0))
        file_row = ttk.Frame(frame)
        file_row.pack(fill=tk.X, pady=3)
        file_var = tk.StringVar()
        ttk.Entry(file_row, textvariable=file_var, width=40).pack(side=tk.LEFT, fill=tk.X, expand=True)
        ttk.Button(file_row, text="浏览",
                   command=lambda: file_var.set(
                       filedialog.askopenfilename(filetypes=[("Icon files", "*.ico;*.png;*.jpg;*.jpeg;*.gif;*.svg")]) or "")
                   ).pack(side=tk.LEFT, padx=3)

        def _do_calc_file():
            filepath = file_var.get()
            if not filepath:
                messagebox.showwarning("提示", "请选择文件")
                return

            def _run():
                r = fetch_icon_hash_from_file(filepath)
                self.root.after(0, lambda: _on_result(r))

            threading.Thread(target=_run, daemon=True).start()

        ttk.Button(file_row, text="计算Hash", command=_do_calc_file).pack(side=tk.LEFT, padx=3)

        ttk.Label(frame, text="计算结果:", font=("", 10, "bold")).pack(anchor=tk.W, pady=(15, 0))
        result_frame = ttk.Frame(frame)
        result_frame.pack(fill=tk.X, pady=5)

        for label, et in [("FOFA:", "fofa"), ("Hunter:", "hunter"), ("Quake:", "quake")]:
            row = ttk.Frame(result_frame)
            row.pack(fill=tk.X, pady=2)
            ttk.Label(row, text=label, width=8).pack(side=tk.LEFT)
            e = ttk.Entry(row, width=55)
            e.pack(side=tk.LEFT, fill=tk.X, expand=True)
            ttk.Button(row, text="查询", command=lambda et=et, ev=e: self._icon_search(et, ev.get())
                       ).pack(side=tk.LEFT, padx=3)
            result_widgets[et] = e

        def _on_result(r):
            if r:
                for k in result_widgets:
                    result_widgets[k].delete(0, tk.END)
                    result_widgets[k].insert(0, r[k])
            else:
                messagebox.showerror("错误", "获取 favicon 失败")

    # ════════════════════════════════════
    # 功能面板: 备忘录语法
    # ════════════════════════════════════
    def _create_syntax_panel(self):
        frame = ttk.Frame(self._content_frame)
        self._function_frames["备忘录语法"] = frame

        engine_name = self.engine_var.get()

        all_syntax = self.config.get("custom_syntax", {})
        if not isinstance(all_syntax, dict):
            all_syntax = {}
        syntax_list = all_syntax.get(engine_name, [])

        # 上方: 引擎切换
        top_bar = ttk.Frame(frame, padding=5)
        top_bar.pack(fill=tk.X)
        ttk.Label(top_bar, text="当前引擎:").pack(side=tk.LEFT)
        syntax_engine_var = tk.StringVar(value=engine_name)

        def _switch_engine(*args):
            nonlocal syntax_list, all_syntax
            eng = syntax_engine_var.get()
            all_syntax = self.config.get("custom_syntax", {})
            if not isinstance(all_syntax, dict):
                all_syntax = {}
            syntax_list = all_syntax.get(eng, [])
            _refresh_tree()

        engine_combo = ttk.Combobox(top_bar, textvariable=syntax_engine_var,
                                    values=ENGINE_TYPES, state="readonly", width=18)
        engine_combo.pack(side=tk.LEFT, padx=6)
        engine_combo.bind("<<ComboboxSelected>>", _switch_engine)

        # 左: 语法列表
        paned = ttk.PanedWindow(frame, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        left = ttk.Frame(paned)
        paned.add(left, weight=1)

        ttk.Label(left, text="备忘录列表:", font=("", 10, "bold")).pack(anchor=tk.W)
        list_frame = ttk.Frame(left)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        tree = ttk.Treeview(list_frame, columns=("syntax",), show="headings", selectmode="browse", height=10)
        tree.heading("#0", text="标签")
        tree.heading("syntax", text="查询语法")
        tree.column("#0", width=120, minwidth=60)
        tree.column("syntax", width=320, minwidth=150)
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)

        def _refresh_tree():
            tree.delete(*tree.get_children())
            for item in syntax_list:
                tree.insert("", tk.END, text=item.get("name", ""),
                            values=(item.get("syntax", ""),))

        _refresh_tree()

        # 右: 编辑区
        right = ttk.Frame(paned)
        paned.add(right, weight=1)

        ttk.Label(right, text="输入查询语法:", font=("", 10, "bold")).pack(anchor=tk.W)
        ttk.Label(right, text="标签将自动取语法第一行作为名称", foreground="gray", font=("", 8)).pack(anchor=tk.W, pady=(2, 5))
        syntax_text = tk.Text(right, height=10, width=30, font=("Consolas", 10))
        syntax_text.pack(fill=tk.BOTH, expand=True, pady=5)

        btn_frame = ttk.Frame(right)
        btn_frame.pack(fill=tk.X, pady=5)

        def _auto_name(syntax):
            """取第一行前30字符作为自动名称"""
            first = syntax.split("\n")[0].strip()
            return first[:30] + (".." if len(first) > 30 else "") if first else "未命名"

        def _save_syntax():
            eng = syntax_engine_var.get()
            syntax = syntax_text.get("1.0", tk.END).strip()
            if not syntax:
                messagebox.showwarning("提示", "请输入查询语法")
                return
            name = _auto_name(syntax)
            # 去重: 同语法内容不再重复添加
            for item in syntax_list:
                if item.get("syntax") == syntax:
                    item["name"] = name
                    break
            else:
                syntax_list.append({"name": name, "syntax": syntax})
            all_cfg = self.config.get("custom_syntax", {})
            if not isinstance(all_cfg, dict):
                all_cfg = {}
            all_cfg[eng] = syntax_list
            self.config["custom_syntax"] = all_cfg
            save_config(self.config)
            _refresh_tree()
            syntax_text.delete("1.0", tk.END)
            messagebox.showinfo("提示", f"[{eng}] 语法已保存")

        ttk.Button(btn_frame, text="保存", command=_save_syntax).pack(side=tk.LEFT, padx=3, fill=tk.X, expand=True)

        def _delete_syntax():
            sel = tree.selection()
            if not sel:
                messagebox.showwarning("提示", "请先选择一个语法")
                return
            item_text = tree.item(sel[0], "text")
            for i, item in enumerate(syntax_list):
                if item.get("name") == item_text:
                    del syntax_list[i]
                    break
            eng = syntax_engine_var.get()
            all_cfg = self.config.get("custom_syntax", {})
            if not isinstance(all_cfg, dict):
                all_cfg = {}
            all_cfg[eng] = syntax_list
            self.config["custom_syntax"] = all_cfg
            save_config(self.config)
            _refresh_tree()
            syntax_text.delete("1.0", tk.END)

        ttk.Button(btn_frame, text="删除", command=_delete_syntax).pack(side=tk.LEFT, padx=3, fill=tk.X, expand=True)

        def _load_selected():
            sel = tree.selection()
            if not sel:
                return
            item_vals = tree.item(sel[0], "values")
            syntax_text.delete("1.0", tk.END)
            syntax_text.insert("1.0", item_vals[0] if item_vals else "")

        ttk.Button(btn_frame, text="编辑选中", command=_load_selected).pack(side=tk.LEFT, padx=3, fill=tk.X, expand=True)

        def _use_syntax():
            sel = tree.selection()
            if not sel:
                return
            item_vals = tree.item(sel[0], "values")
            if item_vals:
                self.engine_var.set(syntax_engine_var.get())
                self.query_entry.delete(0, tk.END)
                self.query_entry.insert(0, item_vals[0])

        ttk.Button(btn_frame, text="使用", command=_use_syntax).pack(side=tk.LEFT, padx=3, fill=tk.X, expand=True)

        ttk.Label(right, text="双击列表项可直接填入查询框", foreground="gray").pack(pady=5)

        tree.bind("<Double-1>", lambda e: _use_syntax())

    # ════════════════════════════════════
    # 功能面板: 端口扫描
    # ════════════════════════════════════
    def _create_portscan_panel(self):
        frame = ttk.Frame(self._content_frame)
        self._function_frames["端口扫描"] = frame

        top = ttk.Frame(frame, padding=10)
        top.pack(fill=tk.X)

        ttk.Label(top, text="目标 IP (每行一个，支持 CIDR):").pack(anchor=tk.W)
        ip_frame = ttk.Frame(top)
        ip_frame.pack(fill=tk.BOTH, pady=5)
        ip_text = tk.Text(ip_frame, height=4, font=("Consolas", 10))
        ip_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        ip_scroll = ttk.Scrollbar(ip_frame, orient=tk.VERTICAL, command=ip_text.yview)
        ip_text.configure(yscrollcommand=ip_scroll.set)
        ip_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        def _import_from_results():
            tab_items = list(self.tabs.items())
            if not tab_items:
                messagebox.showinfo("提示", "没有查询结果可导入")
                return
            ips = set()
            for key, tab in tab_items:
                for r in tab.results:
                    if r.ip:
                        ips.add(r.ip)
            if ips:
                ip_text.delete("1.0", tk.END)
                ip_text.insert("1.0", "\n".join(sorted(ips)))
                messagebox.showinfo("提示", f"已导入 {len(ips)} 个 IP")
            else:
                messagebox.showinfo("提示", "查询结果中没有 IP")

        def _import_from_excel():
            result_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "result")
            filepath = filedialog.askopenfilename(
                title="选择 Excel 文件", initialdir=result_dir,
                filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")])
            if not filepath:
                return
            try:
                wb = load_workbook(filepath, read_only=True)
                ws = wb.active
                ips = set()
                for row in ws.iter_rows(values_only=True):
                    for cell in row:
                        if cell and isinstance(cell, str):
                            cell = cell.strip()
                            if self._is_valid_ip(cell):
                                ips.add(cell)
                wb.close()
                if ips:
                    ip_text.delete("1.0", tk.END)
                    ip_text.insert("1.0", "\n".join(sorted(ips)))
                    messagebox.showinfo("提示", f"已从 Excel 导入 {len(ips)} 个 IP")
                else:
                    messagebox.showinfo("提示", "Excel 中没有找到 IP 地址")
            except Exception as e:
                messagebox.showerror("错误", f"读取 Excel 失败: {e}")

        btn_row = ttk.Frame(top)
        btn_row.pack(fill=tk.X, pady=3)
        ttk.Button(btn_row, text="从查询结果导入", command=_import_from_results).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(btn_row, text="从 Excel 导入", command=_import_from_excel).pack(side=tk.LEFT)

        ttk.Label(top, text="扫描命令 (可修改):").pack(anchor=tk.W, pady=(10, 0))
        cmd_frame = ttk.Frame(top)
        cmd_frame.pack(fill=tk.X, pady=5)
        default_cmd = 'ulimit -n 65535 && ./rustscan -a "$(paste -sd, targets.txt)" -- -sV | tee ports_services.txt'
        cmd_text = tk.Text(cmd_frame, height=3, font=("Consolas", 9), wrap=tk.WORD)
        cmd_text.pack(fill=tk.X)
        cmd_text.insert("1.0", default_cmd)
        ttk.Label(top, text="提示: 命令会在工作目录下执行", foreground="gray", font=("", 8)).pack(anchor=tk.W)

        # 执行日志 + 结果
        mid = ttk.Frame(frame, padding=10)
        mid.pack(fill=tk.BOTH, expand=True)

        ttk.Label(mid, text="执行日志:", font=("", 10, "bold")).pack(anchor=tk.W)
        log_frame = ttk.Frame(mid)
        log_frame.pack(fill=tk.X, pady=5)
        log_text = tk.Text(log_frame, height=5, font=("Consolas", 9), wrap=tk.WORD, state=tk.DISABLED)
        log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        log_scroll = ttk.Scrollbar(log_frame, orient=tk.VERTICAL, command=log_text.yview)
        log_text.configure(yscrollcommand=log_scroll.set)
        log_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        def _log(msg):
            log_text.configure(state=tk.NORMAL)
            log_text.insert(tk.END, msg + "\n")
            log_text.see(tk.END)
            log_text.configure(state=tk.DISABLED)

        ttk.Label(mid, text="扫描结果:", font=("", 10, "bold")).pack(anchor=tk.W, pady=(10, 0))
        result_frame = ttk.Frame(mid)
        result_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        columns = ("ip", "port", "status", "service")
        result_tree = ttk.Treeview(result_frame, columns=columns, show="headings", height=6)
        result_tree.heading("ip", text="IP")
        result_tree.heading("port", text="端口")
        result_tree.heading("status", text="状态")
        result_tree.heading("service", text="服务/版本")
        result_tree.column("ip", width=150)
        result_tree.column("port", width=100)
        result_tree.column("status", width=80)
        result_tree.column("service", width=350)
        result_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        result_scroll = ttk.Scrollbar(result_frame, orient=tk.VERTICAL, command=result_tree.yview)
        result_tree.configure(yscrollcommand=result_scroll.set)
        result_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        status_label = ttk.Label(mid, text="", foreground="gray")
        status_label.pack(anchor=tk.W, pady=3)

        btn_frame = ttk.Frame(frame, padding=10)
        btn_frame.pack(fill=tk.X)

        scan_results = []
        scanning = False
        active_ssh = None
        active_channel = None

        def _stop_scan():
            nonlocal scanning
            if not scanning:
                return
            _log("\n⚠ 正在停止扫描...")
            status_label.configure(text="正在停止...", foreground="orange")
            if active_channel:
                try:
                    active_channel.close()
                except Exception:
                    pass
            if active_ssh:
                try:
                    active_ssh.exec_command(
                        "pid=$(cat /tmp/nssm_portscan.pid 2>/dev/null); "
                        "if [ -n \"$pid\" ]; then "
                        "kill -9 $pid 2>/dev/null; "
                        "pkill -9 -P $pid 2>/dev/null; "
                        "fi; "
                        "rm -f /tmp/nssm_portscan.pid 2>/dev/null",
                        timeout=5
                    )
                except Exception:
                    pass
            scanning = False
            _log("扫描已停止")
            status_label.configure(text="已停止", foreground="gray")

        def _run_scan():
            nonlocal scanning, active_ssh, active_channel
            if scanning:
                messagebox.showinfo("提示", "扫描正在进行中，请等待完成")
                return
            ips_raw = [l.strip() for l in ip_text.get("1.0", tk.END).split("\n") if l.strip()]
            if not ips_raw:
                messagebox.showwarning("提示", "请输入目标 IP")
                return
            scan_cmd_text = cmd_text.get("1.0", tk.END).strip()
            if not scan_cmd_text:
                messagebox.showwarning("提示", "请输入扫描命令")
                return

            result_tree.delete(*result_tree.get_children())
            scan_results.clear()
            log_text.configure(state=tk.NORMAL)
            log_text.delete("1.0", tk.END)
            log_text.configure(state=tk.DISABLED)
            status_label.configure(text="正在扫描...", foreground="blue")

            scanning = True

            def _scan_thread():
                nonlocal scanning, active_ssh, active_channel
                ssh = None
                channel = None
                try:
                    if paramiko is None:
                        self.root.after(0, lambda: _log("✗ paramiko 未安装"))
                        return
                    ssh_cfg = self.config.get("ssh", {})
                    work_dir = ssh_cfg.get("work_dir", "/root")

                    self.root.after(0, lambda: _log(f"[1/3] 连接到 SSH: {ssh_cfg.get('host')}:{ssh_cfg.get('port', 22)}"))

                    ssh = paramiko.SSHClient()
                    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                    ssh.connect(ssh_cfg.get("host"), port=int(ssh_cfg.get("port", 22)),
                                username=ssh_cfg.get("username"), password=ssh_cfg.get("password"),
                                timeout=15)
                    active_ssh = ssh
                    self.root.after(0, lambda: _log("✓ SSH 连接成功"))

                    self.root.after(0, lambda: _log(f"\n[2/3] 写入 {len(ips_raw)} 个目标到 targets.txt"))
                    targets_content = "\n".join(ips_raw)
                    targets_path = f"{work_dir}/targets.txt"
                    b64 = base64.b64encode(targets_content.encode()).decode()
                    write_cmd = f"echo {b64} | base64 -d > {targets_path}"
                    stdin, stdout, stderr = ssh.exec_command(write_cmd)
                    stdout.read()
                    self.root.after(0, lambda: _log("✓ 目标文件写入成功"))

                    self.root.after(0, lambda: _log(f"\n[3/3] 执行扫描命令:"))
                    self.root.after(0, lambda: _log(f"  {scan_cmd_text}"))
                    self.root.after(0, lambda: status_label.configure(text="正在执行扫描...", foreground="blue"))

                    full_cmd = f"echo $$ > /tmp/nssm_portscan.pid; cd {work_dir} && {scan_cmd_text}"
                    stdin, stdout, stderr = ssh.exec_command(full_cmd, timeout=600)
                    channel = stdout.channel
                    active_channel = channel

                    channel.setblocking(0)
                    log_buf = []
                    last_flush = time.time()

                    def _flush():
                        nonlocal log_buf, last_flush
                        if log_buf:
                            chunk = "\n".join(log_buf)
                            self.root.after(0, lambda c=chunk: _log(c))
                            log_buf = []
                            last_flush = time.time()

                    while not channel.exit_status_ready():
                        if channel.recv_ready():
                            data = channel.recv(4096).decode('utf-8', errors='ignore')
                            if data.strip():
                                data_clean = re.sub(r'\x1b\[[0-9;]*[mGKHF]', '', data)
                                log_buf.extend("  " + l for l in data_clean.strip().split("\n"))
                        if channel.recv_stderr_ready():
                            err_data = channel.recv_stderr(4096).decode('utf-8', errors='ignore')
                            if err_data.strip():
                                err_clean = re.sub(r'\x1b\[[0-9;]*[mGKHF]', '', err_data)
                                log_buf.extend("  [stderr] " + l for l in err_clean.strip().split("\n"))
                        if log_buf and time.time() - last_flush > 0.3:
                            _flush()
                        time.sleep(0.05)
                    _flush()

                    exit_status = channel.recv_exit_status()
                    if exit_status == 0:
                        self.root.after(0, lambda: _log("✓ 扫描命令执行成功"))
                    elif exit_status == -1:
                        self.root.after(0, lambda: _log("⚠ 扫描已被用户停止"))
                    else:
                        self.root.after(0, lambda: _log(f"⚠ 扫描命令退出码: {exit_status}"))

                    self.root.after(0, lambda: _log(f"\n读取扫描结果: {work_dir}/ports_services.txt"))
                    self.root.after(0, lambda: status_label.configure(text="正在读取结果...", foreground="blue"))

                    stdin, stdout, stderr = ssh.exec_command(f"cat {work_dir}/ports_services.txt")
                    result_content = stdout.read().decode('utf-8', errors='ignore')

                    if not result_content.strip():
                        self.root.after(0, lambda: _log("⚠ 结果文件为空"))
                    else:
                        self.root.after(0, lambda: _log("✓ 结果文件读取成功"))

                    self._parse_scan_results(result_content, scan_results, result_tree)
                    self.root.after(0, lambda: _log(f"\n✓ 扫描完成: 发现 {len(scan_results)} 个开放端口"))
                    self.root.after(0, lambda: status_label.configure(
                        text=f"扫描完成: 发现 {len(scan_results)} 个开放端口", foreground="green"))
                except Exception as e:
                    self.root.after(0, lambda: _log(f"\n✗ 扫描失败: {e}"))
                    self.root.after(0, lambda: status_label.configure(text=f"扫描失败: {e}", foreground="red"))
                    self.root.after(0, lambda: messagebox.showerror("扫描失败", str(e)))
                finally:
                    active_channel = None
                    active_ssh = None
                    if ssh:
                        try:
                            ssh.close()
                        except Exception:
                            pass
                    scanning = False
                    self.root.after(0, lambda: stop_btn.pack_forget())

            threading.Thread(target=_scan_thread, daemon=True).start()
            stop_btn.pack(side=tk.LEFT, padx=5)

        def _export_scan_results():
            nonlocal scanning
            if scanning:
                messagebox.showinfo("提示", "扫描正在进行中，请等待完成后再导出")
                return
            if not scan_results:
                messagebox.showinfo("提示", "没有扫描结果可导出")
                return
            save_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "result")
            os.makedirs(save_dir, exist_ok=True)
            ts = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
            filepath = os.path.join(save_dir, f"portscan_{ts}.xlsx")
            wb = Workbook()
            ws = wb.active
            ws.title = "端口扫描"
            ws.append(["IP", "端口", "状态", "服务/版本"])
            for r in scan_results:
                ws.append([r["ip"], r["port"], r["status"], r["service"]])
            wb.save(filepath)
            messagebox.showinfo("提示", f"已导出到: {filepath}")

        ttk.Button(btn_frame, text="开始扫描", command=_run_scan).pack(side=tk.LEFT, padx=5)
        stop_btn = ttk.Button(btn_frame, text="停止扫描", command=_stop_scan)
        ttk.Button(btn_frame, text="导出结果", command=_export_scan_results).pack(side=tk.LEFT, padx=5)

    # ════════════════════════════════════
    # 功能面板: 暴力扫描
    # ════════════════════════════════════
    def _create_brutescan_panel(self):
        frame = ttk.Frame(self._content_frame)
        self._function_frames["暴力扫描"] = frame

        top = ttk.Frame(frame, padding=10)
        top.pack(fill=tk.X)

        script_frame = ttk.Frame(top)
        script_frame.pack(fill=tk.X, pady=5)
        ttk.Label(script_frame, text="远程脚本路径:").pack(side=tk.LEFT)
        script_var = tk.StringVar(value=self.config.get("brutescan", {}).get("script_path", ""))
        ttk.Entry(script_frame, textvariable=script_var, width=50, font=("Consolas", 10)).pack(
            side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 0))
        ttk.Label(top, text="示例: /home/ubuntu/brute/scan.sh", foreground="gray", font=("", 8)).pack(anchor=tk.W)

        root_frame = ttk.Frame(top)
        root_frame.pack(fill=tk.X, pady=5)
        ttk.Label(root_frame, text="Root 密码:").pack(side=tk.LEFT)
        root_var = tk.StringVar(value=self.config.get("brutescan", {}).get("root_password", ""))
        ttk.Entry(root_frame, textvariable=root_var, show="*", width=25, font=("Consolas", 10)).pack(
            side=tk.LEFT, padx=(5, 0))
        ttk.Label(top, text="脚本将通过 su -c 以 root 身份执行", foreground="gray", font=("", 8)).pack(anchor=tk.W)

        ttk.Label(top, text="targets.txt 内容 (自由编辑，上传到脚本同目录):").pack(anchor=tk.W, pady=(10, 0))
        target_frame = ttk.Frame(top)
        target_frame.pack(fill=tk.BOTH, pady=5)
        target_text = tk.Text(target_frame, height=6, font=("Consolas", 10))
        target_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        target_scroll = ttk.Scrollbar(target_frame, orient=tk.VERTICAL, command=target_text.yview)
        target_text.configure(yscrollcommand=target_scroll.set)
        target_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        saved_targets = self.config.get("brutescan", {}).get("targets", "")
        if saved_targets:
            target_text.insert("1.0", saved_targets)

        def _save_cfg():
            if "brutescan" not in self.config:
                self.config["brutescan"] = {}
            self.config["brutescan"]["script_path"] = script_var.get().strip()
            self.config["brutescan"]["root_password"] = root_var.get()
            self.config["brutescan"]["targets"] = target_text.get("1.0", tk.END).strip()
            save_config(self.config)
            messagebox.showinfo("提示", "配置已保存")

        ttk.Button(top, text="保存配置", command=_save_cfg).pack(anchor=tk.W, pady=3)

        # 日志
        mid = ttk.Frame(frame, padding=10)
        mid.pack(fill=tk.BOTH, expand=True)
        ttk.Label(mid, text="执行日志:", font=("", 10, "bold")).pack(anchor=tk.W)
        log_frame = ttk.Frame(mid)
        log_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        log_text = tk.Text(log_frame, height=10, font=("Consolas", 9), wrap=tk.WORD, state=tk.DISABLED)
        log_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        log_scroll = ttk.Scrollbar(log_frame, orient=tk.VERTICAL, command=log_text.yview)
        log_text.configure(yscrollcommand=log_scroll.set)
        log_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        def _log(msg):
            log_text.configure(state=tk.NORMAL)
            log_text.insert(tk.END, msg + "\n")
            log_text.see(tk.END)
            log_text.configure(state=tk.DISABLED)

        status_label = ttk.Label(mid, text="", foreground="gray")
        status_label.pack(anchor=tk.W, pady=3)

        btn_frame = ttk.Frame(frame, padding=10)
        btn_frame.pack(fill=tk.X)

        running = False
        active_ssh = None
        active_channel = None

        def _stop_brutescan():
            nonlocal running
            if not running:
                return
            _log("\n⚠ 正在停止...")
            status_label.configure(text="正在停止...", foreground="orange")
            if active_channel:
                try:
                    active_channel.close()
                except Exception:
                    pass
            if active_ssh:
                try:
                    active_ssh.exec_command(
                        "pid=$(cat /tmp/nssm_brute.pid 2>/dev/null); "
                        "if [ -n \"$pid\" ]; then kill -9 $pid 2>/dev/null; pkill -9 -P $pid 2>/dev/null; fi; "
                        "cpid=$(cat /tmp/nssm_brute_child.pid 2>/dev/null); "
                        "if [ -n \"$cpid\" ]; then kill -9 $cpid 2>/dev/null; pkill -9 -P $cpid 2>/dev/null; fi; "
                        "rm -f /tmp/nssm_brute.pid /tmp/nssm_brute_child.pid 2>/dev/null",
                        timeout=5
                    )
                except Exception:
                    pass
            running = False
            _log("已停止")
            status_label.configure(text="已停止", foreground="gray")

        def _run_brutescan():
            nonlocal running, active_ssh, active_channel
            if running:
                messagebox.showinfo("提示", "正在执行中，请等待完成")
                return
            script_path = script_var.get().strip()
            if not script_path:
                messagebox.showwarning("提示", "请输入远程脚本路径")
                return
            root_password = root_var.get()
            if not root_password:
                messagebox.showwarning("提示", "请输入 Root 密码")
                return
            targets_content = target_text.get("1.0", tk.END).strip()
            if not targets_content:
                messagebox.showwarning("提示", "请输入 targets.txt 内容")
                return

            if "brutescan" not in self.config:
                self.config["brutescan"] = {}
            self.config["brutescan"]["script_path"] = script_path
            self.config["brutescan"]["root_password"] = root_password
            self.config["brutescan"]["targets"] = targets_content
            save_config(self.config)

            log_text.configure(state=tk.NORMAL)
            log_text.delete("1.0", tk.END)
            log_text.configure(state=tk.DISABLED)
            status_label.configure(text="正在执行...", foreground="blue")
            running = True

            def _brute_thread():
                nonlocal running, active_ssh, active_channel
                ssh = None
                channel = None
                try:
                    if paramiko is None:
                        self.root.after(0, lambda: _log("✗ paramiko 未安装"))
                        return
                    ssh_cfg = self.config.get("ssh", {})
                    work_dir = os.path.dirname(script_path) if "/" in script_path else ssh_cfg.get("work_dir", "/root")

                    self.root.after(0, lambda: _log(f"[1/4] 连接 SSH: {ssh_cfg.get('host')}:{ssh_cfg.get('port', 22)}"))
                    ssh = paramiko.SSHClient()
                    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                    ssh.connect(ssh_cfg.get("host"), port=int(ssh_cfg.get("port", 22)),
                                username=ssh_cfg.get("username"), password=ssh_cfg.get("password"),
                                timeout=15)
                    active_ssh = ssh
                    self.root.after(0, lambda: _log("OK SSH 连接成功"))

                    targets_path = f"{work_dir}/targets.txt"
                    self.root.after(0, lambda: _log(f"\n[2/4] 写入 targets.txt -> {targets_path}"))
                    b64 = base64.b64encode(targets_content.encode()).decode()
                    write_cmd = f"echo {b64} | base64 -d > {targets_path}"
                    stdin, stdout, stderr = ssh.exec_command(write_cmd)
                    stdout.read()
                    self.root.after(0, lambda: _log("OK targets.txt 写入成功"))

                    self.root.after(0, lambda: _log(f"\n[3/4] su 提权至 root"))
                    self.root.after(0, lambda: _log(f"执行脚本: {script_path}"))
                    self.root.after(0, lambda: status_label.configure(
                        text="正在以 root 身份执行脚本...", foreground="blue"))

                    inner_cmd = f"echo $$ > /tmp/nssm_brute_child.pid; cd {work_dir} && bash {script_path}"
                    su_cmd = f"echo $$ > /tmp/nssm_brute.pid; echo '{shlex.quote(root_password)}' | su -c '{inner_cmd}'"
                    stdin, stdout, stderr = ssh.exec_command(su_cmd, timeout=1800)
                    channel = stdout.channel
                    active_channel = channel

                    channel.setblocking(0)
                    log_buf = []
                    last_flush = time.time()

                    def _flush():
                        nonlocal log_buf, last_flush
                        if log_buf:
                            chunk = "\n".join(log_buf)
                            self.root.after(0, lambda c=chunk: _log(c))
                            log_buf = []
                            last_flush = time.time()

                    while not channel.exit_status_ready():
                        if channel.recv_ready():
                            data = channel.recv(4096).decode('utf-8', errors='ignore')
                            if data.strip():
                                data_clean = re.sub(r'\x1b\[[0-9;]*[mGKHF]', '', data)
                                log_buf.extend("  " + l for l in data_clean.strip().split("\n"))
                        if channel.recv_stderr_ready():
                            err_data = channel.recv_stderr(4096).decode('utf-8', errors='ignore')
                            if err_data.strip():
                                err_clean = re.sub(r'\x1b\[[0-9;]*[mGKHF]', '', err_data)
                                log_buf.extend("  [stderr] " + l for l in err_clean.strip().split("\n"))
                        if log_buf and time.time() - last_flush > 0.3:
                            _flush()
                        time.sleep(0.05)
                    _flush()

                    exit_status = channel.recv_exit_status()
                    if exit_status == 0:
                        self.root.after(0, lambda: _log("\nOK 脚本执行完成"))
                        self.root.after(0, lambda: status_label.configure(text="执行完成", foreground="green"))
                    elif exit_status == -1:
                        self.root.after(0, lambda: _log("\n⚠ 已被用户停止"))
                    else:
                        self.root.after(0, lambda: _log(f"\n⚠ 脚本退出码: {exit_status}"))
                        self.root.after(0, lambda: status_label.configure(
                            text=f"执行完成 (退出码: {exit_status})", foreground="orange"))
                except Exception as e:
                    self.root.after(0, lambda: _log(f"\n✗ 执行失败: {e}"))
                    self.root.after(0, lambda: status_label.configure(text=f"执行失败: {e}", foreground="red"))
                finally:
                    active_channel = None
                    active_ssh = None
                    if ssh:
                        try:
                            ssh.close()
                        except Exception:
                            pass
                    running = False
                    self.root.after(0, lambda: stop_btn2.pack_forget())

            threading.Thread(target=_brute_thread, daemon=True).start()
            stop_btn2.pack(side=tk.LEFT, padx=5)

        ttk.Button(btn_frame, text="开始执行", command=_run_brutescan).pack(side=tk.LEFT, padx=5)
        stop_btn2 = ttk.Button(btn_frame, text="停止执行", command=_stop_brutescan)

    # ════════════════════════════════════
    # 功能面板: 去重合并
    # ════════════════════════════════════
    def _create_dedup_panel(self):
        frame = ttk.Frame(self._content_frame)
        self._function_frames["去重合并"] = frame

        result_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "result")
        os.makedirs(result_dir, exist_ok=True)

        top = ttk.Frame(frame, padding=5)
        top.pack(fill=tk.BOTH, expand=True)

        left = ttk.Frame(top)
        left.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 3))

        def _refresh_file_list():
            file_tree.delete(*file_tree.get_children())
            for f in sorted([f for f in os.listdir(result_dir)
                            if f.endswith(".xlsx") and not f.startswith("~$")]):
                file_tree.insert("", tk.END, text=f"☐ {f}")

        ttk.Label(left, text="result 文件夹 (双击切换选择):", font=("", 10, "bold")).pack(anchor=tk.W)
        list_frame = ttk.Frame(left)
        list_frame.pack(fill=tk.BOTH, expand=True, pady=3)

        file_tree = ttk.Treeview(list_frame, show="tree")
        file_tree.column("#0", width=350)
        file_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        vsb = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=file_tree.yview)
        file_tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)

        def _toggle_check(event):
            item = file_tree.identify_row(event.y)
            if not item: return
            text = file_tree.item(item, "text")
            if text.startswith("☑ "):
                file_tree.item(item, text=text.replace("☑ ", "☐ "))
            else:
                file_tree.item(item, text=text.replace("☐ ", "☑ "))

        file_tree.bind("<Double-1>", _toggle_check)

        _refresh_file_list()

        right = ttk.Frame(top)
        right.pack(side=tk.RIGHT, fill=tk.BOTH, padx=(3, 0))
        ttk.Label(right, text="主域名筛选 (每行一个, 留空=不筛选):",
                  font=("", 10, "bold")).pack(anchor=tk.W)
        domain_text = tk.Text(right, font=("Consolas", 10), width=26)
        domain_text.pack(fill=tk.BOTH, expand=True)

        bottom = ttk.Frame(frame, padding=5)
        bottom.pack(fill=tk.X)
        stats_label = ttk.Label(bottom, text="", foreground="gray")
        stats_label.pack(side=tk.LEFT)
        progress_bar = ttk.Progressbar(bottom, mode="indeterminate", length=100)

        def _get_selected_files():
            checked = []
            for item in file_tree.get_children():
                text = file_tree.item(item, "text")
                if text.startswith("☑ "):
                    checked.append(text[2:])
            return checked

        def _get_domains():
            return [d.strip() for d in domain_text.get("1.0", tk.END).split("\n") if d.strip()]

        def _run_preview():
            files = _get_selected_files()
            if not files:
                messagebox.showwarning("提示", "请选择至少一个文件")
                return
            domains = _get_domains()
            progress_bar.pack(side=tk.LEFT, padx=10)
            progress_bar.start()
            stats_label.configure(text="正在分析...", foreground="blue")

            def _bg():
                all_rows = self._dedup_read_files(result_dir, files)
                total = len(all_rows)
                deduped = self._dedup_dedup(all_rows)
                self._dedup_urlscan(deduped, result_dir)
                dedup_count = len(deduped)
                filtered = self._dedup_filter(deduped, domains)
                filter_count = len(filtered)
                self.root.after(0, lambda: _show_stats(total, dedup_count, filter_count))

            threading.Thread(target=_bg, daemon=True).start()

        def _show_stats(total, dedup, filtered):
            progress_bar.stop()
            progress_bar.pack_forget()
            stats_label.configure(
                text=f"合并 {total} 条 → 去重后 {dedup} 条 → 筛选后 {filtered} 条",
                foreground="green")

        def _run_merge():
            files = _get_selected_files()
            if not files:
                messagebox.showwarning("提示", "请选择至少一个文件")
                return
            domains = _get_domains()
            progress_bar.pack(side=tk.LEFT, padx=10)
            progress_bar.start()
            stats_label.configure(text="正在合并...", foreground="blue")

            def _bg():
                all_rows = self._dedup_read_files(result_dir, files)
                deduped = self._dedup_dedup(all_rows)
                self._dedup_urlscan(deduped, result_dir)
                if domains:
                    deduped = self._dedup_filter(deduped, domains)
                output = self._dedup_write_xlsx(deduped, os.path.join(result_dir, "合并去重_资产测绘.xlsx"))
                self.root.after(0, lambda: _done(output, len(deduped)))

            threading.Thread(target=_bg, daemon=True).start()

        def _done(path, count):
            progress_bar.stop()
            progress_bar.pack_forget()
            stats_label.configure(text=f"完成: {count} 条 → {os.path.basename(path)}", foreground="green")
            messagebox.showinfo("完成", f"合并去重完成: {count} 条\n{path}")

        btn_frame = ttk.Frame(bottom)
        ttk.Button(btn_frame, text="刷新列表", command=_refresh_file_list, width=8).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="预览统计", command=_run_preview, width=10).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="开始合并", command=_run_merge, width=10).pack(side=tk.LEFT, padx=3)
        btn_frame.pack(side=tk.RIGHT)

    # ════════════════════════════════════
    # 功能面板: 查询结果导出
    # ════════════════════════════════════
    def _create_export_panel(self):
        frame = ttk.Frame(self._content_frame, padding="5")
        self._function_frames["查询结果导出"] = frame

        ttk.Label(frame, text="勾选需要导出的查询结果:", font=("", 10, "bold")).pack(anchor=tk.W, pady=5)

        list_frame = ttk.Frame(frame)
        list_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        canvas = tk.Canvas(list_frame)
        scrollbar = ttk.Scrollbar(list_frame, orient=tk.VERTICAL, command=canvas.yview)
        scroll_frame = ttk.Frame(canvas)
        scroll_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        check_vars = {}

        def _refresh():
            for w in scroll_frame.winfo_children():
                w.destroy()
            check_vars.clear()
            for key, tab in self.tabs.items():
                engine, query = key
                if not tab.results:
                    continue
                var = tk.BooleanVar(value=True)
                check_vars[key] = var
                label = f"[{engine}] {query[:60]}{'...' if len(query) > 60 else ''}  ({len(tab.results)}条)"
                ttk.Checkbutton(scroll_frame, text=label, variable=var).pack(anchor=tk.W, pady=1)
            if not check_vars:
                ttk.Label(scroll_frame, text="暂无查询结果", foreground="gray").pack(anchor=tk.W, pady=10)

        _refresh()

        btn_frame = ttk.Frame(frame, padding=5)
        btn_frame.pack(fill=tk.X)
        ttk.Button(btn_frame, text="全选",
                   command=lambda: [v.set(True) for v in check_vars.values()]).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="全不选",
                   command=lambda: [v.set(False) for v in check_vars.values()]).pack(side=tk.LEFT, padx=3)
        ttk.Button(btn_frame, text="刷新列表", command=_refresh).pack(side=tk.LEFT, padx=10)

        def _do_export():
            selected = {}
            for key, tab in self.tabs.items():
                if key in check_vars and check_vars[key].get():
                    selected[key] = tab
            if not selected:
                messagebox.showwarning("提示", "必须选择至少一个 tab 再导出数据")
                return

            save_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "result")
            os.makedirs(save_dir, exist_ok=True)

            try:
                ts = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
                count = 0
                for key, tab in selected.items():
                    engine, query = key
                    if not tab.results:
                        continue
                    safe_name = engine + "_" + query[:30]
                    for ch in '\\/*?:[]"\'|<>':
                        safe_name = safe_name.replace(ch, '')
                    safe_name = safe_name.strip()[:50] or "查询结果"
                    filepath = os.path.join(save_dir, f"{safe_name}_{ts}.xlsx")
                    wb = Workbook()
                    ws = wb.active
                    ws.title = "查询结果"
                    ws.append([f"[{engine}] {query}"])
                    ws.append(["序号", "HOST", "标题", "IP", "域名", "端口", "协议", "服务指纹", "城市", "ICP备案"])
                    for i, r in enumerate(tab.results):
                        host = format_host_url(r.host, r.protocol, r.port)
                        ws.append([i + 1, host, r.title, r.ip, r.domain, r.port,
                                   r.protocol, r.server, r.city, r.icp])
                    wb.save(filepath)
                    count += 1
                messagebox.showinfo("提示", f"导出完成: {count} 个文件\n{save_dir}")
            except Exception as e:
                messagebox.showerror("错误", f"导出失败: {e}")

        ttk.Button(btn_frame, text="导出选中", command=_do_export).pack(side=tk.RIGHT, padx=5)

    # ════════════════════════════════════
    # 功能面板: 工具配置
    # ════════════════════════════════════
    def _create_config_panel(self):
        frame = ttk.Frame(self._content_frame)
        self._function_frames["工具配置"] = frame

        cfg = load_config()
        inner_nb = ttk.Notebook(frame)
        inner_nb.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # -- FOFA --
        f1 = ttk.Frame(inner_nb)
        inner_nb.add(f1, text="FOFA")
        ttk.Label(f1, text="FOFA Email:").pack(anchor=tk.W, padx=10, pady=(10, 0))
        e_fofa_email = ttk.Entry(f1, width=50); e_fofa_email.pack(fill=tk.X, padx=10)
        e_fofa_email.insert(0, cfg.get("fofa", {}).get("email", ""))
        ttk.Label(f1, text="FOFA Key:").pack(anchor=tk.W, padx=10, pady=(10, 0))
        e_fofa_key = ttk.Entry(f1, width=50, show="*"); e_fofa_key.pack(fill=tk.X, padx=10)
        e_fofa_key.insert(0, cfg.get("fofa", {}).get("key", ""))
        ttk.Label(f1, text="API 地址:").pack(anchor=tk.W, padx=10, pady=(10, 0))
        e_fofa_url = ttk.Entry(f1, width=50); e_fofa_url.pack(fill=tk.X, padx=10)
        e_fofa_url.insert(0, cfg.get("fofa", {}).get("url", "https://fofa.info"))
        ttk.Label(f1, text="每页条数 / 最大条数:").pack(anchor=tk.W, padx=10, pady=(10, 0))
        pf = ttk.Frame(f1); pf.pack(fill=tk.X, padx=10)
        e_fofa_size = ttk.Entry(pf, width=8); e_fofa_size.pack(side=tk.LEFT)
        e_fofa_size.insert(0, str(cfg.get("fofa", {}).get("size", 50)))
        ttk.Label(pf, text=" / ").pack(side=tk.LEFT)
        e_fofa_max = ttk.Entry(pf, width=8); e_fofa_max.pack(side=tk.LEFT)
        e_fofa_max.insert(0, str(cfg.get("fofa", {}).get("maxsize", 10000)))

        # -- Hunter --
        f2 = ttk.Frame(inner_nb)
        inner_nb.add(f2, text="Hunter")
        ttk.Label(f2, text="Hunter API Key (多key换行):").pack(anchor=tk.W, padx=10, pady=(10, 0))
        e_hunter_key = tk.Text(f2, height=3, width=50); e_hunter_key.pack(fill=tk.X, padx=10)
        e_hunter_key.insert("1.0", cfg.get("hunter", {}).get("apikey", ""))
        ttk.Label(f2, text="每页条数 / 最大条数:").pack(anchor=tk.W, padx=10, pady=(10, 0))
        pf2 = ttk.Frame(f2); pf2.pack(fill=tk.X, padx=10)
        e_hunter_size = ttk.Entry(pf2, width=8); e_hunter_size.pack(side=tk.LEFT)
        e_hunter_size.insert(0, str(cfg.get("hunter", {}).get("size", 50)))
        ttk.Label(pf2, text=" / ").pack(side=tk.LEFT)
        e_hunter_max = ttk.Entry(pf2, width=8); e_hunter_max.pack(side=tk.LEFT)
        e_hunter_max.insert(0, str(cfg.get("hunter", {}).get("maxsize", 10000)))

        # -- Quake --
        f3 = ttk.Frame(inner_nb)
        inner_nb.add(f3, text="Quake")
        ttk.Label(f3, text="Quake API Key:").pack(anchor=tk.W, padx=10, pady=(10, 0))
        e_quake_key = ttk.Entry(f3, width=50, show="*"); e_quake_key.pack(fill=tk.X, padx=10)
        e_quake_key.insert(0, cfg.get("quake", {}).get("apikey", ""))
        ttk.Label(f3, text="每页条数 / 最大条数:").pack(anchor=tk.W, padx=10, pady=(10, 0))
        pf3 = ttk.Frame(f3); pf3.pack(fill=tk.X, padx=10)
        e_quake_size = ttk.Entry(pf3, width=8); e_quake_size.pack(side=tk.LEFT)
        e_quake_size.insert(0, str(cfg.get("quake", {}).get("size", 50)))
        ttk.Label(pf3, text=" / ").pack(side=tk.LEFT)
        e_quake_max = ttk.Entry(pf3, width=8); e_quake_max.pack(side=tk.LEFT)
        e_quake_max.insert(0, str(cfg.get("quake", {}).get("maxsize", 10000)))

        # -- ZoomEye --
        f4 = ttk.Frame(inner_nb)
        inner_nb.add(f4, text="ZoomEye")
        ttk.Label(f4, text="ZoomEye API Key:").pack(anchor=tk.W, padx=10, pady=(10, 0))
        e_zoomeye_key = ttk.Entry(f4, width=50, show="*"); e_zoomeye_key.pack(fill=tk.X, padx=10)
        e_zoomeye_key.insert(0, cfg.get("zoomeye", {}).get("apikey", ""))
        ttk.Label(f4, text="最大条数:").pack(anchor=tk.W, padx=10, pady=(10, 0))
        e_zoomeye_max = ttk.Entry(f4, width=10); e_zoomeye_max.pack(fill=tk.X, padx=10)
        e_zoomeye_max.insert(0, str(cfg.get("zoomeye", {}).get("maxsize", 10000)))

        # -- 0.zone --
        f5 = ttk.Frame(inner_nb)
        inner_nb.add(f5, text="0.zone")
        ttk.Label(f5, text="零零信安 zone_key_id:").pack(anchor=tk.W, padx=10, pady=(10, 0))
        e_zero_key = ttk.Entry(f5, width=50, show="*"); e_zero_key.pack(fill=tk.X, padx=10)
        e_zero_key.insert(0, cfg.get("zerokey", {}).get("zone_key_id", ""))
        ttk.Label(f5, text="每页条数 / 最大条数:").pack(anchor=tk.W, padx=10, pady=(10, 0))
        pf5 = ttk.Frame(f5); pf5.pack(fill=tk.X, padx=10)
        e_zero_size = ttk.Entry(pf5, width=8); e_zero_size.pack(side=tk.LEFT)
        e_zero_size.insert(0, str(cfg.get("zerokey", {}).get("size", 100)))
        ttk.Label(pf5, text=" / ").pack(side=tk.LEFT)
        e_zero_max = ttk.Entry(pf5, width=8); e_zero_max.pack(side=tk.LEFT)
        e_zero_max.insert(0, str(cfg.get("zerokey", {}).get("maxsize", 10000)))

        # -- Proxy --
        f6 = ttk.Frame(inner_nb)
        inner_nb.add(f6, text="代理")
        ttk.Label(f6, text="代理IP:").pack(anchor=tk.W, padx=10, pady=(10, 0))
        e_proxy_ip = ttk.Entry(f6, width=30); e_proxy_ip.pack(fill=tk.X, padx=10)
        e_proxy_ip.insert(0, cfg.get("proxy", {}).get("ip", "127.0.0.1"))
        ttk.Label(f6, text="代理端口:").pack(anchor=tk.W, padx=10, pady=(10, 0))
        e_proxy_port = ttk.Entry(f6, width=10); e_proxy_port.pack(fill=tk.X, padx=10)
        e_proxy_port.insert(0, str(cfg.get("proxy", {}).get("port", "7890")))
        ttk.Label(f6, text="代理类型:").pack(anchor=tk.W, padx=10, pady=(10, 0))
        pt = ttk.Combobox(f6, values=["HTTP", "SOCKS"], state="readonly", width=8)
        pt.pack(fill=tk.X, padx=10); pt.set(cfg.get("proxy", {}).get("proxytype", "HTTP"))
        ttk.Label(f6, text="用户名(可选):").pack(anchor=tk.W, padx=10, pady=(10, 0))
        e_proxy_user = ttk.Entry(f6, width=20); e_proxy_user.pack(fill=tk.X, padx=10)
        e_proxy_user.insert(0, cfg.get("proxy", {}).get("username", ""))
        ttk.Label(f6, text="密码(可选):").pack(anchor=tk.W, padx=10, pady=(10, 0))
        e_proxy_pass = ttk.Entry(f6, width=20, show="*"); e_proxy_pass.pack(fill=tk.X, padx=10)
        e_proxy_pass.insert(0, cfg.get("proxy", {}).get("password", ""))
        isrun_var = tk.BooleanVar(value=bool(cfg.get("proxy", {}).get("isrun", False)))
        ttk.Checkbutton(f6, text="启用代理", variable=isrun_var).pack(anchor=tk.W, padx=10, pady=10)

        # -- SSH --
        f7 = ttk.Frame(inner_nb)
        inner_nb.add(f7, text="SSH")
        ttk.Label(f7, text="SSH 服务器地址:").pack(anchor=tk.W, padx=10, pady=(10, 0))
        e_ssh_host = ttk.Entry(f7, width=40); e_ssh_host.pack(fill=tk.X, padx=10)
        e_ssh_host.insert(0, cfg.get("ssh", {}).get("host", ""))
        ttk.Label(f7, text="SSH 端口:").pack(anchor=tk.W, padx=10, pady=(10, 0))
        e_ssh_port = ttk.Entry(f7, width=10); e_ssh_port.pack(fill=tk.X, padx=10)
        e_ssh_port.insert(0, str(cfg.get("ssh", {}).get("port", "22")))
        ttk.Label(f7, text="用户名:").pack(anchor=tk.W, padx=10, pady=(10, 0))
        e_ssh_user = ttk.Entry(f7, width=30); e_ssh_user.pack(fill=tk.X, padx=10)
        e_ssh_user.insert(0, cfg.get("ssh", {}).get("username", ""))
        ttk.Label(f7, text="密码:").pack(anchor=tk.W, padx=10, pady=(10, 0))
        e_ssh_pass = ttk.Entry(f7, width=30, show="*"); e_ssh_pass.pack(fill=tk.X, padx=10)
        e_ssh_pass.insert(0, cfg.get("ssh", {}).get("password", ""))
        ttk.Label(f7, text="工作目录 (targets.txt所在目录):").pack(anchor=tk.W, padx=10, pady=(10, 0))
        e_ssh_dir = ttk.Entry(f7, width=40); e_ssh_dir.pack(fill=tk.X, padx=10)
        e_ssh_dir.insert(0, cfg.get("ssh", {}).get("work_dir", "/root"))

        def _test_ssh():
            if paramiko is None:
                messagebox.showerror("错误", "paramiko 未安装")
                return
            try:
                ssh = paramiko.SSHClient()
                ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                ssh.connect(e_ssh_host.get(), port=int(e_ssh_port.get()),
                            username=e_ssh_user.get(), password=e_ssh_pass.get(), timeout=10)
                stdin, stdout, stderr = ssh.exec_command('echo "SSH连接成功"')
                result = stdout.read().decode().strip()
                ssh.close()
                messagebox.showinfo("测试连接", f"连接成功！\n{result}")
            except Exception as ex:
                messagebox.showerror("测试连接", f"连接失败：{ex}")

        ttk.Button(f7, text="测试连接", command=_test_ssh).pack(anchor=tk.W, padx=10, pady=10)

        def _save_all():
            new_cfg = load_config()
            new_cfg["fofa"] = {"email": e_fofa_email.get(), "key": e_fofa_key.get(),
                               "url": e_fofa_url.get(), "size": int(e_fofa_size.get() or 50),
                               "maxsize": int(e_fofa_max.get() or 10000)}
            new_cfg["hunter"] = {"apikey": e_hunter_key.get("1.0", tk.END).strip(),
                                 "size": int(e_hunter_size.get() or 50),
                                 "maxsize": int(e_hunter_max.get() or 10000)}
            new_cfg["quake"] = {"apikey": e_quake_key.get(),
                                "size": int(e_quake_size.get() or 50),
                                "maxsize": int(e_quake_max.get() or 10000)}
            new_cfg["zoomeye"] = {"apikey": e_zoomeye_key.get(),
                                  "maxsize": int(e_zoomeye_max.get() or 10000)}
            new_cfg["zerokey"] = {"zone_key_id": e_zero_key.get(),
                                  "size": int(e_zero_size.get() or 100),
                                  "maxsize": int(e_zero_max.get() or 10000)}
            new_cfg["proxy"] = {"ip": e_proxy_ip.get(), "port": int(e_proxy_port.get() or 7890),
                                "proxytype": pt.get(),
                                "username": e_proxy_user.get(), "password": e_proxy_pass.get(),
                                "isrun": isrun_var.get()}
            new_cfg["ssh"] = {"host": e_ssh_host.get(), "port": int(e_ssh_port.get() or 22),
                              "username": e_ssh_user.get(), "password": e_ssh_pass.get(),
                              "work_dir": e_ssh_dir.get()}
            save_config(new_cfg)
            self.config = new_cfg
            self.engine = NssmSearchEngine(new_cfg)
            messagebox.showinfo("提示", "设置已保存")

        ttk.Button(frame, text="保存设置", command=_save_all).pack(pady=10)

    # ════════════════════════════════════
    # 功能面板: ICP查询
    # ════════════════════════════════════
    def _create_icp_panel(self):
        frame = ttk.Frame(self._content_frame)
        self._function_frames["ICP查询"] = frame

        # ── 查询区域 ──
        query_frame = ttk.Frame(frame, padding="8")
        query_frame.pack(fill=tk.X)

        ttk.Label(query_frame, text="ICP备案查询", font=("", 12, "bold")).pack(anchor=tk.W)

        row1 = ttk.Frame(query_frame)
        row1.pack(fill=tk.X, pady=(8, 4))
        ttk.Label(row1, text="查询关键词:").pack(side=tk.LEFT)
        self.icp_name_entry = ttk.Entry(row1, width=50)
        self.icp_name_entry.pack(side=tk.LEFT, padx=6, fill=tk.X, expand=True)
        self.icp_name_entry.bind("<Return>", lambda e: self._do_icp_query())

        ttk.Label(row1, text="类型:").pack(side=tk.LEFT, padx=(10, 0))
        self.icp_type_var = tk.StringVar(value="web")
        self.icp_type_labels = ["web", "APP", "小程序", "快应用"]
        self.icp_type_keys = {"web": "web", "APP": "app", "小程序": "mini", "快应用": "kuai"}
        icp_type_combo = ttk.Combobox(row1, textvariable=self.icp_type_var,
                                       values=self.icp_type_labels,
                                       state="readonly", width=10)
        icp_type_combo.pack(side=tk.LEFT, padx=6)

        self.icp_black_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(row1, text="违法违规查询", variable=self.icp_black_var).pack(side=tk.LEFT, padx=6)

        self.icp_query_btn = ttk.Button(row1, text="查询", command=self._do_icp_query, width=6)
        self.icp_query_btn.pack(side=tk.LEFT, padx=10)

        # ── 结果显示区域 ──
        result_frame = ttk.Frame(frame)
        result_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=2)

        # 状态标签
        self.icp_status_label = ttk.Label(result_frame, text="", foreground="gray")
        self.icp_status_label.pack(fill=tk.X, pady=(0, 2))

        # 树形表格
        self.icp_cols = ("#", "主办单位", "域名/服务名", "备案号", "类型", "负责人", "审核日期")
        self.icp_col_widths = [35, 180, 200, 180, 80, 80, 100]
        self.icp_tree = ttk.Treeview(result_frame, columns=self.icp_cols,
                                     show="headings", selectmode="extended")
        for col, w in zip(self.icp_cols, self.icp_col_widths):
            self.icp_tree.heading(col, text=col)
            self.icp_tree.column(col, width=w, minwidth=30)

        icp_vsb = ttk.Scrollbar(result_frame, orient=tk.VERTICAL, command=self.icp_tree.yview)
        self.icp_tree.configure(yscrollcommand=icp_vsb.set)
        self.icp_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        icp_vsb.pack(side=tk.RIGHT, fill=tk.Y)

        self.icp_tree.tag_configure("even", background="#ffffff")
        self.icp_tree.tag_configure("odd", background="#f2f2f2")

        # ── 底部操作栏 ──
        bottom = ttk.Frame(frame, padding="5")
        bottom.pack(fill=tk.X)
        ttk.Button(bottom, text="复制域名", command=self._icp_copy_domains).pack(side=tk.LEFT, padx=4)
        ttk.Button(bottom, text="复制备案号", command=self._icp_copy_licence).pack(side=tk.LEFT, padx=4)

        # 存储当前结果
        self.icp_results = []
        self.icp_querying = False

    def _do_icp_query(self):
        if self.icp_querying:
            return
        name = self.icp_name_entry.get().strip()
        if not name:
            messagebox.showwarning("提示", "请输入查询关键词（主办单位名称或域名）")
            return

        query_label = self.icp_type_var.get()
        query_type = self.icp_type_keys.get(query_label, "web")
        black = self.icp_black_var.get()

        self.icp_querying = True
        self.icp_query_btn.configure(state="disabled")
        self.icp_status_label.configure(text="正在查询...", foreground="blue")
        self.icp_tree.delete(*self.icp_tree.get_children())

        def _run():
            engine = IcpQueryEngine()
            try:
                if black:
                    result = engine.query_blacklist(name, query_type)
                else:
                    result = engine.query(name, query_type)
                self.root.after(0, lambda r=result, n=name, qt=query_type, b=black: self._on_icp_done(r, n, qt, b))
            except Exception as e:
                self.root.after(0, lambda msg=str(e): self._on_icp_error(msg))

        threading.Thread(target=_run, daemon=True).start()

    def _on_icp_done(self, result, name, query_type, black):
        self.icp_querying = False
        self.icp_query_btn.configure(state="normal")

        if not result["success"]:
            self.icp_status_label.configure(
                text=f"查询失败: {result.get('message', '未知错误')}", foreground="red")
            return

        items = result["list"]
        total = result["total"]
        type_label = BLACK_TYPE_MAP[query_type]["name"] if black else QUERY_TYPE_MAP[query_type]["name"]
        self.icp_status_label.configure(
            text=f"[{type_label}] {name} — 共 {total} 条，返回 {len(items)} 条", foreground="green")

        self.icp_results = items
        self._icp_black_mode = black

        if black:
            self._show_icp_black_results(items)
        else:
            self._show_icp_normal_results(items)

    def _on_icp_error(self, msg):
        self.icp_querying = False
        self.icp_query_btn.configure(state="normal")
        self.icp_status_label.configure(text=f"查询出错: {msg}", foreground="red")

    def _icp_copy_domains(self):
        """一键复制所有去重域名"""
        if not self.icp_results:
            return
        domains = []
        seen = set()
        for item in self.icp_results:
            d = item.get("serviceName", "")
            if d and d not in seen:
                seen.add(d)
                domains.append(d)
        if domains:
            self.root.clipboard_clear()
            self.root.clipboard_append("\n".join(domains))
            self.icp_status_label.configure(
                text=f"已复制 {len(domains)} 个域名到剪贴板", foreground="green")

    def _icp_copy_licence(self):
        """复制主体备案号（去后缀，去重）"""
        if not self.icp_results:
            return
        licences = []
        seen = set()
        for item in self.icp_results:
            lic = item.get("mainLicence", "")
            if not lic:
                continue
            if lic not in seen:
                seen.add(lic)
                licences.append(lic)
        if licences:
            self.root.clipboard_clear()
            self.root.clipboard_append("\n".join(licences))
            self.icp_status_label.configure(
                text=f"已复制 {len(licences)} 个备案号到剪贴板", foreground="green")

    def _show_icp_normal_results(self, items):
        # 切换到正常列
        self.icp_cols = ("#", "主办单位", "域名/服务名", "备案号", "类型", "负责人", "审核日期")
        self.icp_col_widths = [35, 180, 200, 180, 80, 80, 100]
        self.icp_tree.configure(columns=self.icp_cols)
        for col, w in zip(self.icp_cols, self.icp_col_widths):
            self.icp_tree.heading(col, text=col)
            self.icp_tree.column(col, width=w, minwidth=30)

        self.icp_tree.delete(*self.icp_tree.get_children())
        for i, item in enumerate(items):
            tag = "even" if i % 2 == 0 else "odd"
            self.icp_tree.insert("", tk.END, iid=str(i), values=(
                i + 1,
                item.get("unitName", ""),
                item.get("serviceName", ""),
                item.get("serviceLicence", ""),
                item.get("contentTypeName", ""),
                item.get("leaderName", ""),
                item.get("updateRecordTime", ""),
            ), tags=(tag,))

    def _show_icp_black_results(self, items):
        # 切换到黑名单列
        self.icp_cols = ("#", "域名/服务名", "违法违规类型", "违法违规内容", "处罚日期", "处罚结果")
        self.icp_col_widths = [35, 200, 120, 200, 100, 180]
        self.icp_tree.configure(columns=self.icp_cols)
        for col, w in zip(self.icp_cols, self.icp_col_widths):
            self.icp_tree.heading(col, text=col)
            self.icp_tree.column(col, width=w, minwidth=30)

        self.icp_tree.delete(*self.icp_tree.get_children())
        for i, item in enumerate(items):
            tag = "even" if i % 2 == 0 else "odd"
            self.icp_tree.insert("", tk.END, iid=str(i), values=(
                i + 1,
                item.get("webSite") or item.get("serviceName", ""),
                item.get("illegalType", ""),
                item.get("illegalContent", ""),
                item.get("punishDate", ""),
                item.get("punishResult", ""),
            ), tags=(tag,))


    # ════════════════════════════════════
    # Tab 管理（查询结果在"查询结果"面板的内部子标签中）
    # ════════════════════════════════════
    def _get_tab_key(self, engine_type, query):
        return (engine_type, query)

    def _find_existing_tab(self, engine_type, query):
        for key, tab in self.tabs.items():
            if key[0] == engine_type and tab.check_keywords_match(query):
                return key, tab
        return None, None

    def _create_result_tab(self, engine_type, query):
        try:
            page_size = int(self.page_size_var.get())
        except ValueError:
            page_size = 50
        try:
            default_pages = int(self.max_page_var.get())
        except ValueError:
            default_pages = 1
        full = self.full_var.get()

        tab = SearchTab(self._result_notebook, engine_type, query, self.engine,
                        page_size, default_pages, full)
        title = tab.get_tab_title()
        self._result_notebook.add(tab.frame, text=title)
        self._result_notebook.select(tab.frame)

        key = self._get_tab_key(engine_type, query)
        self.tabs[key] = tab
        return tab

    def _remove_result_tab(self, key):
        tab = self.tabs.pop(key, None)
        if tab:
            self._result_notebook.forget(tab.frame)

    # ── 子标签（查询结果）右键菜单 ──
    def _show_sub_tab_menu(self, event):
        try:
            idx = self._result_notebook.index("@%d,%d" % (event.x, event.y))
            tab_text = self._result_notebook.tab(idx, "text")
            self._result_notebook.select(idx)
            if tab_text == "语法速查":
                self._sub_tab_menu.entryconfigure("关闭", state="disabled")
                self._sub_tab_menu.entryconfigure("关闭其他", state="disabled")
                self._sub_tab_menu.entryconfigure("关闭所有结果", state="disabled")
            else:
                self._sub_tab_menu.entryconfigure("关闭", state="normal")
                self._sub_tab_menu.entryconfigure("关闭其他", state="normal")
                self._sub_tab_menu.entryconfigure("关闭所有结果", state="normal")
            self._sub_tab_menu.post(event.x_root, event.y_root)
        except Exception:
            pass

    def _close_selected_subtab(self):
        cur = self._result_notebook.select()
        cur_text = self._result_notebook.tab(cur, "text")
        if cur_text == "语法速查":
            return
        for key, tab in list(self.tabs.items()):
            if str(tab.frame) == str(cur):
                self._remove_result_tab(key)
                break

    def _close_other_subtabs(self):
        cur = self._result_notebook.select()
        for key in list(self.tabs.keys()):
            if str(self.tabs[key].frame) != str(cur):
                self._remove_result_tab(key)

    def _close_all_subtabs(self):
        for key in list(self.tabs.keys()):
            self._remove_result_tab(key)

    # ════════════════════════════════════
    # 搜索逻辑
    # ════════════════════════════════════
    def _start_search(self, engines=None):
        if self._batch_running > 0:
            return
        query = self.query_entry.get().strip()
        if not query:
            messagebox.showwarning("提示", "请输入查询语法")
            return

        if engines is None:
            if self.multi_var.get():
                engines = [e for e in ("FOFA", "Quake") if e != self.engine_var.get()] + [self.engine_var.get()]
            else:
                engines = [self.engine_var.get()]

        for engine_type in engines:
            self._search_single(engine_type, query)

    def _search_single(self, engine_type, query):
        self.query_history.append((engine_type, query))
        existing_key, existing_tab = self._find_existing_tab(engine_type, query)
        if existing_tab:
            if existing_tab.query != query:
                existing_tab.query = query
                existing_tab.results = []
                existing_tab.total = 0
                existing_tab.loaded_pages = set()
                existing_tab.max_page = 1
                title = existing_tab.get_tab_title()
                self._result_notebook.tab(existing_tab.frame, text=title)
                existing_tab.start_search(1)
            self._result_notebook.select(existing_tab.frame)
            self._switch_to_query_result_tab()
            return

        tab = self._create_result_tab(engine_type, query)
        tab.start_search(1)
        self._switch_to_query_result_tab()

    def _switch_func_tab(self, name):
        """切换功能面板：显示 name 对应的面板，隐藏其余"""
        for fname, frame in self._function_frames.items():
            if fname == name:
                frame.pack(fill=tk.BOTH, expand=True)
            else:
                frame.pack_forget()

    def _switch_to_query_result_tab(self):
        """切换到功能标签栏的 '查询结果' 按钮"""
        self._switch_func_tab("查询结果")

    # ════════════════════════════════════
    # 批量查询
    # ════════════════════════════════════
    def _do_batch_search(self, engine_type, queries, max_per, full=False):
        with self._batch_lock:
            self._batch_running += 1
        self.search_btn.configure(state="disabled")

        total_queries = len(queries)
        if queries and isinstance(queries[0], tuple):
            summary_parts = [f"{d}: {q[:25]}..." for d, q in queries[:3]]
        else:
            summary_parts = [q[:30] for q in queries[:3]]
        query_summary = "批量: " + ", ".join(summary_parts)
        tab = self._create_result_tab(engine_type, query_summary)
        self._switch_to_query_result_tab()
        tab.is_loading = True
        tab.progress.pack(side=tk.LEFT, padx=10)
        tab.progress.start()

        all_results = []

        def _run():
            try:
                for i, item in enumerate(queries):
                    if isinstance(item, tuple):
                        domain_tag, actual_query = item
                    else:
                        domain_tag, actual_query = "", item.strip()
                    if not actual_query:
                        continue
                    display = f"[{domain_tag}] {actual_query[:50]}" if domain_tag else actual_query[:60]
                    tab.frame.after(0, lambda idx=i, total=total_queries, d=display:
                        tab.status_label.configure(
                            text=f"批量查询 [{idx+1}/{total}]: {d}...", foreground="blue"))
                    results, _, err = self.engine.search_batch(engine_type, actual_query, max_per, full)
                    if err:
                        tab.frame.after(0, lambda idx=i, e=err:
                            tab.status_label.configure(
                                text=f"批量查询 [{idx+1}/{total_queries}] 出错: {e}", foreground="red"))
                        continue
                    all_results.extend(results)
                    if (i + 1) % 10 == 0 or i == total_queries - 1:
                        tab.frame.after(0, lambda r=list(all_results): self._update_batch_table(tab, r))
                    if i < total_queries - 1:
                        delay = {"Hunter": 2, "Quake": 1.5}.get(engine_type, 0.5)
                        time.sleep(delay)
            finally:
                tab.frame.after(0, lambda: self._on_batch_done(tab, all_results))

        threading.Thread(target=_run, daemon=True).start()

    def _update_batch_table(self, tab, results):
        tab.results = results
        tab._refresh_table()

    def _on_batch_done(self, tab, results):
        with self._batch_lock:
            self._batch_running = max(0, self._batch_running - 1)
            running = self._batch_running
        tab.is_loading = False
        tab.progress.stop()
        tab.progress.pack_forget()
        if running == 0:
            self.search_btn.configure(state="normal")

        tab.results = results
        tab.total = len(results)
        tab.max_page = 1
        tab.loaded_pages = {1}
        tab._refresh_table()
        tab._update_load_state()
        tab.status_label.configure(
            text=f"批量查询完成: 共 {len(results)} 条", foreground="green")

    # ════════════════════════════════════
    # Icon 相关
    # ════════════════════════════════════
    def _icon_search(self, engine_type, hash_str):
        if not hash_str:
            return
        eng_map = {"fofa": "FOFA", "hunter": "Hunter", "quake": "Quake"}
        self.engine_var.set(eng_map.get(engine_type, "FOFA"))
        self.query_entry.delete(0, tk.END)
        self.query_entry.insert(0, hash_str)
        self._start_search()

    # ════════════════════════════════════
    # 去重合并核心函数
    # ════════════════════════════════════
    HEADER_SIG = {"HOST", "IP", "域名", "端口", "协议"}
    DEDUP_KEYS = ("域名", "IP", "端口")

    def _dedup_detect_header(self, rows_iter):
        best_row, best_headers, best_score = 0, [], 0
        for row_idx, row_vals in enumerate(rows_iter, 1):
            if row_idx > 5:
                break
            score = sum(1 for v in row_vals
                        if v is not None and str(v).strip() in self.HEADER_SIG)
            if score > best_score:
                best_score, best_row, best_headers = score, row_idx, list(row_vals)
        return best_row, best_headers

    def _dedup_read_file(self, filepath):
        wb = load_workbook(filepath, read_only=True)
        ws = wb.active
        all_rows = list(ws.iter_rows(values_only=True))
        wb.close()
        if not all_rows:
            return []
        header_row, headers = self._dedup_detect_header(all_rows)
        if header_row == 0:
            return []
        rows = []
        for row_vals in all_rows[header_row:]:
            row_dict = {}
            for i, val in enumerate(row_vals):
                if i < len(headers) and headers[i] is not None:
                    row_dict[headers[i]] = val
            if any(v is not None for v in row_dict.values()):
                rows.append(row_dict)
        return rows

    def _dedup_read_files(self, directory, filenames):
        all_rows = []
        for fn in filenames:
            fp = os.path.join(directory, fn)
            try:
                rows = self._dedup_read_file(fp)
                all_rows.extend(rows)
            except Exception as e:
                print(f"[去重合并] 读取 {fn} 失败: {e}")
        return all_rows

    def _dedup_dedup(self, rows):
        def _norm(val):
            return str(val).strip() if val is not None else ""
        seen = {}
        result = []
        for r in rows:
            key = tuple(_norm(r.get(k)) for k in self.DEDUP_KEYS)
            if key not in seen:
                seen[key] = r
                result.append(r)
            else:
                existing = seen[key]
                existing_fp = _norm(existing.get("服务指纹", ""))
                new_fp = _norm(r.get("服务指纹", ""))
                if new_fp and new_fp not in existing_fp:
                    existing["服务指纹"] = (existing_fp + " | " + new_fp) if existing_fp else new_fp
        return result

    @staticmethod
    def _extract_hostname(url_or_host):
        s = str(url_or_host).strip()
        if not s:
            return ""
        if not s.startswith(("http://", "https://")):
            s = "http://" + s
        try:
            return urlparse(s).hostname or ""
        except Exception:
            return ""

    def _dedup_urlscan(self, rows, result_dir):
        urlscan_files = [f for f in os.listdir(result_dir)
                         if f.startswith("UrlScan") and f.endswith(".xlsx")]
        for uf in urlscan_files:
            fp = os.path.join(result_dir, uf)
            try:
                wb = load_workbook(fp)
                ws = wb.active
                url_col = banner_col = None
                for cell in ws[1]:
                    if cell.value == "Url":
                        url_col = cell.column - 1
                    elif cell.value == "Banner":
                        banner_col = cell.column - 1
                if url_col is None or banner_col is None:
                    wb.close()
                    continue

                for row_data in ws.iter_rows(min_row=2):
                    url_cell = row_data[url_col] if url_col < len(row_data) else None
                    banner_cell = row_data[banner_col] if banner_col < len(row_data) else None
                    if not url_cell or not banner_cell:
                        continue
                    url = url_cell.value
                    banner = banner_cell.value
                    if not url or not banner:
                        continue

                    is_red = False
                    if banner_cell.font and banner_cell.font.color:
                        color = banner_cell.font.color
                        if hasattr(color, 'rgb') and color.rgb:
                            is_red = 'FF0000' in str(color.rgb).upper()

                    host = self._extract_hostname(str(url))
                    if not host:
                        continue
                    for dedup_row in rows:
                        row_domain = str(dedup_row.get("域名", "")).strip() if dedup_row.get("域名") else ""
                        row_host = self._extract_hostname(str(dedup_row.get("HOST", "")))
                        if host == row_domain or host == row_host:
                            existing_fp = str(dedup_row.get("服务指纹", "")).strip() if dedup_row.get("服务指纹") else ""
                            existing_set = set(p.strip() for p in existing_fp.replace(",", "|").split("|") if p.strip())
                            new_parts = [p.strip() for p in str(banner).replace(",", "|").split("|") if p.strip()]
                            added = [p for p in new_parts if p not in existing_set]
                            if added:
                                dedup_row["服务指纹"] = (existing_fp + " | " + " | ".join(added)) if existing_fp else " | ".join(added)
                                if is_red:
                                    dedup_row.setdefault("_red_fp", set()).update(added)
                            elif is_red:
                                dedup_row.setdefault("_red_fp", set()).update(p for p in new_parts if p in existing_set)
                            break
                wb.close()
                print(f"[去重合并] UrlScan {uf}: Banner 已融入")
            except Exception as e:
                print(f"[去重合并] UrlScan {uf} 失败: {e}")

    def _dedup_filter(self, rows, main_domains):
        if not main_domains:
            return rows
        result = []
        for r in rows:
            domain = str(r.get("域名", "")).strip() if r.get("域名") else ""
            if domain:
                dl = domain.lower()
                if any(dl == md.lower() or dl.endswith("." + md.lower())
                       for md in main_domains):
                    result.append(r)
            else:
                result.append(r)
        return result

    def _dedup_sort(self, rows):
        def _key(r):
            ip_s = str(r.get("IP", "")).strip() if r.get("IP") else ""
            try:
                parts = [int(p) for p in ip_s.split(".")]
            except (ValueError, AttributeError):
                parts = [0, 0, 0, 0]
            port_s = str(r.get("端口", "")).strip() if r.get("端口") else "0"
            try:
                port_n = int(port_s)
            except (ValueError, AttributeError):
                port_n = 0
            return (parts, port_n)
        rows.sort(key=_key)

    def _dedup_write_xlsx(self, rows, output_path):
        wb = Workbook()
        ws = wb.active
        ws.title = "合并去重"

        header_font = Font(name="微软雅黑", size=11, bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        h_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
        border = Border(left=Side(style="thin"), right=Side(style="thin"),
                        top=Side(style="thin"), bottom=Side(style="thin"))
        d_align = Alignment(vertical="center")
        link_font = Font(name="微软雅黑", size=10, color="0563C1", underline="single")

        out_cols = ["序号", "HOST", "标题", "IP", "域名", "端口",
                    "协议", "服务指纹", "城市", "利用", "结果"]
        for ci, h in enumerate(out_cols, 1):
            c = ws.cell(row=1, column=ci, value=h)
            c.font, c.fill, c.alignment, c.border = header_font, header_fill, h_align, border

        host_col = out_cols.index("HOST") + 1
        fp_col = out_cols.index("服务指纹") + 1

        self._dedup_sort(rows)
        for ri, rd in enumerate(rows, 2):
            ws.cell(row=ri, column=1, value=ri - 1).alignment = d_align
            ws.cell(row=ri, column=1).border = border
            for ci, cn in enumerate(out_cols[1:], 2):
                val = rd.get(cn, "") if cn not in ("利用", "结果") else ""
                if cn == "HOST" and val:
                    val = format_host_url(str(val), str(rd.get("协议", "")), rd.get("端口", 0))
                c = ws.cell(row=ri, column=ci)
                c.alignment, c.border = d_align, border

                if ci == fp_col and val and rd.get("_red_fp"):
                    red_set = rd["_red_fp"]
                    parts = str(val).split(" | ")
                    blocks = []
                    for pi, part in enumerate(parts):
                        if pi > 0:
                            blocks.append(TextBlock(InlineFont(rFont='微软雅黑', sz=10), text=" | "))
                        if part in red_set:
                            blocks.append(TextBlock(InlineFont(rFont='微软雅黑', sz=10, color='FF0000'), text=part))
                        else:
                            blocks.append(TextBlock(InlineFont(rFont='微软雅黑', sz=10), text=part))
                    c.value = CellRichText(*blocks)
                else:
                    c.value = val

                if ci == host_col and val:
                    vs = str(val)
                    if not vs.startswith(("http://", "https://")):
                        proto = str(rd.get("协议", "")).lower()
                        vs = ("https://" if ("https" in proto or "ssl" in proto) else "http://") + vs
                    c.hyperlink = vs
                    c.font = link_font

        widths = {1: 8, 2: 42, 3: 28, 4: 18, 5: 32, 6: 8,
                  7: 12, 8: 18, 9: 12, 10: 14, 11: 20}
        for col, w in widths.items():
            ws.column_dimensions[get_column_letter(col)].width = w
        ws.freeze_panes = "A2"

        try:
            wb.save(output_path)
        except PermissionError:
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            name, ext = os.path.splitext(output_path)
            output_path = f"{name}_{ts}{ext}"
            wb.save(output_path)
        return output_path

    # ════════════════════════════════════
    # 工具函数
    # ════════════════════════════════════
    def _is_valid_ip(self, ip_str):
        pattern = r'^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$'
        match = re.match(pattern, ip_str)
        if match:
            return all(0 <= int(num) <= 255 for num in match.groups())
        return False

    def _parse_scan_results(self, content, scan_results, result_tree):
        lines = content.split("\n")
        current_ip = None
        for line in lines:
            line = line.strip()
            if not line:
                continue
            ip_match = re.search(r'Nmap scan report for (?:\S+ \()?(\d+\.\d+\.\d+\.\d+)', line)
            if ip_match:
                current_ip = ip_match.group(1)
                continue
            port_match = re.match(r'(\d+)/(tcp|udp)\s+(open|closed|filtered)\s+(\S+)(?:\s+(.+))?', line)
            if port_match and current_ip:
                port = port_match.group(1)
                protocol = port_match.group(2)
                status = port_match.group(3)
                service_name = port_match.group(4)
                version = port_match.group(5) if port_match.group(5) else ""
                if status == "open":
                    service_info = f"{service_name} {version}".strip()
                    result = {
                        "ip": current_ip,
                        "port": f"{port}/{protocol}",
                        "status": status,
                        "service": service_info
                    }
                    scan_results.append(result)
                    self.root.after(0, lambda r=result:
                                    result_tree.insert("", tk.END, values=(r["ip"], r["port"], r["status"], r["service"])))

    def _guess_service(self, port):
        port_map = {
            "21": "FTP", "22": "SSH", "23": "Telnet", "25": "SMTP", "53": "DNS",
            "80": "HTTP", "110": "POP3", "143": "IMAP", "443": "HTTPS", "445": "SMB",
            "3306": "MySQL", "3389": "RDP", "5432": "PostgreSQL", "5900": "VNC",
            "6379": "Redis", "8080": "HTTP-Proxy", "8443": "HTTPS-Alt", "27017": "MongoDB"
        }
        return port_map.get(str(port), "Unknown")

    def _on_close(self):
        self.root.destroy()

    def run(self):
        self.root.mainloop()


def main():
    NssmToolGUI().run()


if __name__ == "__main__":
    main()
